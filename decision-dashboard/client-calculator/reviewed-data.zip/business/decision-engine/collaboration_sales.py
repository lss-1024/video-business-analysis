"""联名客户销售与同单位销量预测；成本、利润和财务匹配均不参与。"""
from collections import defaultdict
from datetime import date
from functools import lru_cache
import json, math
import engine
import forecast_link

SCOPE='联名客户'

def analyze(orders,items,meta,forecasts=True):
    cutoff=date.fromisoformat(meta.get('viewObservationEnd' if forecasts else 'viewDisplayEnd') or max(r['日期'] for r in orders))
    selected=[r for r in orders if r['渠道']==SCOPE]
    details=[r for r in items if r['渠道']==SCOPE]
    if not selected:return {'汇总':[],'月度':[],'预测':[],'周预测':[],'明细':[]}
    month=cutoff.isoformat()[:7]
    money=forecast_link.analyze(selected,SCOPE,cutoff) if forecasts else {}
    weeks_money=forecast_link.weekly(selected,SCOPE,cutoff)['周预测'] if forecasts else []
    units=sorted({r.get('数量单位') or '单位未提供' for r in details})
    summary=[];monthly=[];forecasts=[];weekly=[];source=[]
    for unit in units:
        rs=[r for r in details if (r.get('数量单位') or '单位未提供')==unit]
        qty_rows=[]
        for r in rs:
            if r.get('数量') is None:continue
            # 金额模型在同单位的实际数量序列上重拟合，不使用金额/均价转换销量。
            qty_rows.append({**r,'总销额':r['数量']})
        qty_complete=all(r.get('数量') is not None for r in rs)
        can_predict=forecasts and qty_complete and unit!='单位未提供'
        quantity=forecast_link.analyze(qty_rows,SCOPE,cutoff) if can_predict else {}
        weeks_qty=forecast_link.weekly(qty_rows,SCOPE,cutoff)['周预测'] if can_predict else []
        current=[r for r in rs if r['日期'].startswith(month)]
        base={'范围':SCOPE,'数量单位':unit,'观察截止':cutoff.isoformat(),'当前月份':month,
              '正向销量':sum(r['数量'] for r in rs if r.get('数量') is not None and r['数量']>0) if qty_complete else None,
              '退货数量':sum(r['数量'] for r in rs if r.get('数量') is not None and r['数量']<0) if qty_complete else None,
              '净销量':engine.total(rs,'数量') if qty_complete else None,
              '本月净销量':engine.total(current,'数量') if qty_complete else None,
              '数量单位推断行数':sum(r.get('数量单位依据','').startswith('同一原文件') for r in rs),
              '月度销量目标':None,'实际销量达成率':None,'预计销量达成率':None,
              '本月预计净销量':quantity.get('整月销售估算'),'本月余期预计净销量':quantity.get('剩余期间销售估算'),
              '数量来源行数':len(rs),'成本':None,'毛利':None,'净利润':None,'利润处理':'不计算利润','财务对账':'不参与'}
        summary.append(base)
        for m in sorted({r['日期'][:7] for r in rs}):
            part=[r for r in rs if r['日期'].startswith(m)]
            monthly.append({'范围':SCOPE,'月份':m+'-01','数量单位':unit,'净销量':engine.total(part,'数量') if all(r.get('数量') is not None for r in part) else None,
                            '正向销量':sum(r['数量'] for r in part if (r.get('数量') or 0)>0),'退货数量':sum(r['数量'] for r in part if (r.get('数量') or 0)<0),
                            '总销额':engine.total(part,'总销额'),'月份状态':'截至观察日，未完结' if m==month else '历史记录','利润处理':'不计算利润'})
        forecasts.append({'范围':SCOPE,'月份':month,'数量单位':unit,'本月已发生净销量':base['本月净销量'],'余期预计净销量':quantity.get('剩余期间销售估算'),
                          '整月预计净销量':quantity.get('整月销售估算'),'销量预测方法':quantity.get('方法') or '数量或单位不足，暂不预测',
                          '销量参考下沿':quantity.get('参考下沿'),'销量参考上沿':quantity.get('参考上沿'),
                          '销量余期回测MAE':quantity.get('回测MAE'),'销量回测月数':quantity.get('回测月数',0),
                          '本月已发生总销额':money.get('本月实际销售'),'余期预计总销额':money.get('剩余期间销售估算'),'整月预计总销额':money.get('整月销售估算'),
                          '金额预测方法':money.get('方法'),'金额余期回测MAE':money.get('回测MAE'),'金额回测月数':money.get('回测月数',0),
                          '预测说明':'数量和金额分别拟合；周为交易日正向采购，月为发货日有符号净销量/净销售。参考带为历史MAE，不是置信区间。没有库存与终端动销，不作实际库存推断。'})
        for w in weeks_money:
            q=next((v for v in weeks_qty if v['周开始日期']==w['周开始日期']),{})
            weekly.append({'范围':SCOPE,'周开始日期':w['周开始日期'],'周结束日期':w['周结束日期'],'数量单位':unit,
                           '预计整周正向采购量':q.get('预测值'),'本周已发生采购量':q.get('本周已发生额'),
                           '数量预测方法':q.get('方法'),'数量回测MAE':q.get('回测MAE'),'数量回测周数':q.get('回测周数',0),
                           '预计整周正向采购额':w.get('预测值'),'金额预测方法':w.get('方法')})
    for r in details:
        source.append({'范围':SCOPE,**{f:r.get(f) for f in ['日期','交易日期','发货日期','原订单编号','原合并客户名称','客户网名','商品编码','商品名称','规格','数量','数量单位','原数量单位','数量单位依据','总销额','渠道产品类型','业务单元','26年7月对应大区','来源工作表','来源行号']},'利润处理':'不计算利润'})
    return {'汇总':summary,'月度':monthly,'预测':forecasts,'周预测':weekly,'明细':source}

@lru_cache(maxsize=1)
def cached(stamp):
    data=engine.load_current();orders,items,*_=engine.validate(data['records'])
    return analyze(orders,items,data['meta'])

def with_target(target,unit):
    result=cached((engine.LOCAL/'current.json').stat().st_mtime_ns)
    value=float(target)
    if not math.isfinite(value) or value<=0:raise ValueError('月度销量目标须为大于0的有限数值')
    row=next((r for r in result['汇总'] if r['数量单位']==unit),None)
    if row is None:raise ValueError('没有该数量单位的联名数据')
    return {**row,'月度销量目标':value,'实际销量达成率':row['本月净销量']/value if row['本月净销量'] is not None else None,
            '预计销量达成率':row['本月预计净销量']/value if row['本月预计净销量'] is not None else None,
            '目标口径':'当前输入的月度净销量目标；未写回原表，未保存为正式目标'}

def add_snapshot(snapshot,orders,items,meta,forecasts=True):
    result=analyze(orders,items,meta,forecasts)
    source={'provider':'本地原始订单联名商品分组','files':[meta['name']],
            'evidenceFlow':[{'title':'筛选顺序','detail':'先取26年7月对应业务单元包含大客户、大单品、线下闭环；1—6月交易日期排除线上分销；符合范围的IP联名商品改归联名客户，保留原客户信息。订单与商品金额分别使用，汇总只计一次。'},
                            {'title':'数量单位','detail':'原表单位为空时，只按同一工作簿同商品编码唯一非空单位映射；保留原数量单位及推断依据。不同单位不混加，不从金额反推销量。'},
                            {'title':'计算与模型','detail':'collaboration_sales.py调用forecast_link，在金额和每种单位的数量上分别重拟合，保留周模型和月模型。现有目标缺失，达成率保持null；网页输入目标仅作试算。联名不参与成本、毛利、净利润或财务对账。'}],
            'metricDefinitions':[{'label':'联名实际与预测','definition':'净销量为带符号商品数量之和，负数为退货数量；净销售额取BN总销额。目标达成率=本月净销量/同单位月目标；预计达成率=整月预计净销量/同单位月目标。模型误差非独立验证，预测可能受稀疏采购和退货影响。','componentIds':['collaboration-sales','collaboration-monthly','collaboration-forecast','collaboration-weekly','collaboration-source']}]}
    for key,rows in result.items():
        query={'汇总':'summary','月度':'monthly','预测':'forecast','周预测':'weekly','明细':'source'}[key]
        snapshot['queries']['collaboration_'+query]={'rows':rows,'source':source}
