"""降价情景的实际基线；订单总览与商品明细分别保持原粒度。"""
from collections import defaultdict
from copy import deepcopy
from decimal import Decimal
import json
import engine

ALL_PRODUCTS='__all_products__'

def total(rows,field):
    return float(sum((Decimal(str(r[field])) for r in rows),Decimal(0))) if rows and all(r.get(field) is not None for r in rows) else None

def allowed(r):
    return r.get('利润处理')!='不计算利润' and r.get('渠道')!='联名客户'

def product_key(name,unit):
    return json.dumps([name,unit],ensure_ascii=False,separators=(',',':'))

def build_rows(orders,items,scopes):
    baselines=[];details=[]
    by_scope=defaultdict(list);by_order_scope=defaultdict(list)
    for row in items:
        for scope in (row['渠道'],engine.ALL):by_scope[scope].append(row)
    for row in orders:
        for scope in (row['渠道'],engine.ALL):by_order_scope[scope].append(row)
    for scope in scopes:
        os=by_order_scope[scope];rs=by_scope[scope];metrics=engine.financial_metrics(os)
        baselines.append({'范围':scope,'选择键':ALL_PRODUCTS,'合并产品名称':'全部产品','数量单位':'',
            '净销售额':metrics['利润分析销售额'],'财务成本':metrics['财务成本'],'毛利额':metrics['毛利额'],'毛利率':metrics['毛利率'],
            '数量':None,'商品行数':len([r for r in rs if allowed(r)]),'成本缺失行数':metrics['成本缺失笔数'],
            '不计利润销售额':metrics['不计利润销售额'],'来源粒度':'订单','包含商品编码':''})
        groups=defaultdict(list);detail_groups=defaultdict(list)
        for row in rs:
            name=row.get('合并产品名称','').strip();unit=row.get('数量单位') or '原表单位未填'
            if allowed(row):groups[(name,unit)].append(row)
            detail_groups[(name,row.get('商品编码',''),row.get('规格') or '规格未提供',row.get('促销机制') or '机制未提供',unit,allowed(row))].append(row)
        for (name,unit),rows in groups.items():
            revenue=total(rows,'总销额');cost=total(rows,'财务成本总金额');profit=revenue-cost if revenue is not None and cost is not None else None
            baselines.append({'范围':scope,'选择键':product_key(name,unit),'合并产品名称':name,'数量单位':unit,
                '净销售额':revenue,'财务成本':cost,'毛利额':profit,'毛利率':profit/revenue if profit is not None and revenue else None,
                '数量':total(rows,'数量'),'商品行数':len(rows),'成本缺失行数':sum(r.get('财务成本总金额') is None for r in rows),
                '不计利润销售额':0,'来源粒度':'商品','包含商品编码':' / '.join(sorted({r.get('商品编码','') for r in rows}))})
        for (name,sku,spec,mechanism,unit,eligible),rows in detail_groups.items():
            revenue=total(rows,'总销额');cost=total(rows,'财务成本总金额') if eligible else None
            details.append({'范围':scope,'选择键':product_key(name,unit),'合并产品名称':name,'商品编码':sku,
                '商品名称':' / '.join(sorted({r.get('商品名称','').strip() for r in rows if r.get('商品名称','').strip()})) or '商品名称未提供',
                '规格':spec,'促销机制':mechanism,'数量单位':unit,'数量':total(rows,'数量'),'明细净收入':revenue,
                '明细毛利':revenue-cost if revenue is not None and cost is not None else None,'商品行数':len(rows),
                '利润口径':'计利润' if eligible else '联名不计利润'})
    return baselines,details

def add_snapshot(snapshot,orders,items):
    baselines,details=build_rows(orders,items,snapshot['businessContext']['scopes'])
    source=deepcopy(snapshot['queries']['products']['source'])
    source['evidenceFlow']=[*source.get('evidenceFlow',[]),{'title':'降价情景实际基线','detail':'全部产品从同范围订单财务指标读取，与上方毛利率同分子同分母；产品从原表ED合并产品名字及数量单位聚合源商品BN总销额与EP财务成本总金额。保留负退单；成本缺失不补零，联名不计利润。'}]
    source['metricDefinitions']=[*source.get('metricDefinitions',[]),{'label':'实际基线与降价模拟','definition':'实际毛利率=(净销售额-财务成本)/净销售额；先汇总金额再计算，非平均SKU毛利率。降价模拟默认使用实际毛利率，手动调整只作为假设；固定单位成本和产品组合，模拟销售额=基线销售额*(1-d)*(1+g)，模拟成本=基线销售额*(1-m)*(1+g)，模拟毛利=基线销售额*(m-d)*(1+g)，保原毛利所需销量倍数=m/(m-d)，仅m>d有效。模拟不修改实际经营指标，不自动预测降价带来的销量，未计新增费用。','componentIds':['promotion-simulator','product-performance']}]
    snapshot['queries']['promotion_baselines']={'rows':baselines,'source':source}
    snapshot['queries']['promotion_products']={'rows':sorted(details,key=lambda r:-(r['明细净收入'] or 0)),'source':source}

def calculate(margin,discount,growth,revenue=None):
    import math
    m=float(margin)/100;d=float(discount)/100;g=float(growth)/100
    if not all(math.isfinite(x) for x in (m,d,g)) or not (0<m<=1 and 0<=d<=1 and g>=-1):raise ValueError('参数超出范围')
    result={'quantityMultiple':m/(m-d) if m>d else None,'requiredGrowth':d/(m-d) if m>d else None,'profitChange':(m-d)*(1+g)/m-1,
        'scenarioMargin':(m-d)/(1-d) if d<1 else None}
    if revenue is not None:
        revenue=float(revenue)
        if not math.isfinite(revenue) or revenue<=0:raise ValueError('基线销售额必须为正数')
        result.update(scenarioRevenue=revenue*(1-d)*(1+g),scenarioCost=revenue*(1-m)*(1+g),scenarioProfit=revenue*(m-d)*(1+g),baselineProfit=revenue*m)
    return result
