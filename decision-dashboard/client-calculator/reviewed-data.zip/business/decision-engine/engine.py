"""课程经营看板：本地计算，按用户要求保留原始客户编号。"""
from __future__ import annotations
import csv, io, json, math, hashlib, os, statistics, subprocess, sys
from collections import defaultdict, Counter
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
APP = ROOT / 'decision-dashboard'
LOCAL = HERE / 'private'
NODE = Path('C:/Users/87774/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
BUILDER = Path('D:/GPTData/Data/codex-home/plugins/cache/openai-curated-remote/data-analytics/1.0.11/scripts/data-app.mjs')
FIELDS = next(csv.reader((ROOT/'课程复核_1080P/统一底表_设计版.csv').open(encoding='utf-8-sig')))
FIELDS += [f for f in ['合并客户名称','原经营渠道','客户网名','原合并客户名称','合并名称来源','合并名称依据','商品名称'] if f not in FIELDS]
FIELDS += [f for f in ['数量单位','来源工作表','来源行号','客户编号来源'] if f not in FIELDS]
FIELDS += [f for f in ['交易日期','发货日期','日期依据'] if f not in FIELDS]
FIELDS += [f for f in ['渠道产品类型','26年7月对应大区','利润处理','来源财务成本总金额','原数量单位','数量单位依据'] if f not in FIELDS]
FIELDS += [f for f in ['合并产品名称'] if f not in FIELDS]
ALL = '全部渠道'

def num(v):
    if v is None or str(v).strip() == '': return None
    try:
        n = float(str(v).replace(',', ''))
        if not math.isfinite(n): raise ValueError('非有限数值')
        return n
    except (ValueError, TypeError): raise ValueError(f'无法识别数值：{str(v)[:50]}')

def day(v):
    s = str(v or '').strip()
    if not s: return ''
    if s.replace('.', '', 1).isdigit() and float(s) > 30000:
        return (date(1899, 12, 30) + timedelta(days=int(float(s)))).isoformat()
    s = s[:10].replace('/', '-').replace('.', '-')
    try: return date.fromisoformat(s).isoformat()
    except ValueError: raise ValueError(f'日期须为YYYY-MM-DD：{s}')

def total(rows, field):
    vals = [Decimal(str(r[field])) for r in rows if r.get(field) is not None]
    return float(sum(vals, Decimal(0)))

def ratio(a,b): return a / b if b else None
def now(): return datetime.now(timezone.utc).isoformat()
def read_table(data: bytes, filename: str):
    if filename.lower().endswith('.csv'):
        try: text = data.decode('utf-8-sig')
        except UnicodeDecodeError: text = data.decode('gb18030')
        reader = csv.DictReader(io.StringIO(text))
        if len(reader.fieldnames or []) != len(set(reader.fieldnames or [])): raise ValueError('存在重复表头')
        return [dict(r) for r in reader]
    if not filename.lower().endswith('.xlsx'): raise ValueError('请导入CSV或XLSX文件')
    ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with ZipFile(io.BytesIO(data)) as z:
        if sum(x.file_size for x in z.infolist()) > 180_000_000: raise ValueError('Excel解压后超过180MB')
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            strings=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',ns)]
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        rid = wb.find('m:sheets/m:sheet',ns).get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
        rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
        target = next(x.get('Target') for x in rels if x.get('Id')==rid)
        sheet = target.lstrip('/') if target.startswith('/') else 'xl/'+target
        tree=ET.fromstring(z.read(sheet)); rows=[]
        for row in tree.findall('m:sheetData/m:row',ns):
            cells={}
            for cell in row.findall('m:c',ns):
                ref=cell.get('r','A1'); letters=''.join(c for c in ref if c.isalpha()); idx=0
                for c in letters: idx=idx*26+ord(c)-64
                if cell.find('m:f',ns) is not None: raise ValueError('底表含Excel公式，请先粘贴为数值，避免读取旧缓存')
                val=cell.find('m:v',ns); val=val.text if val is not None else ''
                if cell.get('t')=='s': val=strings[int(val)] if val else ''
                elif cell.get('t')=='inlineStr': val=''.join(cell.find('m:is',ns).itertext())
                cells[idx-1]=val
            rows.append(cells)
        if not rows: raise ValueError('第一张工作表没有数据')
        headers=[str(rows[0].get(i,'')).strip() for i in range(max(rows[0])+1)]
        if len(headers)!=len(set(headers)): raise ValueError('存在重复或空白表头')
        return [{h:str(r.get(i,'') or '').strip() for i,h in enumerate(headers)} for r in rows[1:] if any(r.values())]

def current_source():
    active=LOCAL/'active-order-source.json'
    if active.exists():
        info=json.loads(active.read_text(encoding='utf-8'))
        prepared=json.loads(Path(info['preparedFile']).read_text(encoding='utf-8'))
        return prepared['records'],prepared['meta']
    path=ROOT/'看板底数据_2026/01_销售成本明细.csv'
    rows=list(csv.DictReader(path.open(encoding='utf-8-sig')))
    mapping_file=LOCAL/'customer-name-source/records.ndjson'
    mapping_manifest=json.loads((mapping_file.parent/'manifest.json').read_text(encoding='utf-8'))
    assert mapping_manifest['complete'] and mapping_manifest['has_more'] is False
    names={r['record_id']:r.get('合并客户名字') or '' for r in map(json.loads,mapping_file.read_text(encoding='utf-8').splitlines())}
    assert len(names)==mapping_manifest['rows']
    missing_ids={r['订单行编号'] for r in rows}-names.keys()
    if missing_ids:raise ValueError(f'{len(missing_ids)}条旧订单在本轮客户名称来源中未匹配，停止更新')
    inferred_file=LOCAL/'customer-name-inference.json'
    inferred=json.loads(inferred_file.read_text(encoding='utf-8')) if inferred_file.exists() else {'mapping':{},'manifest':{}}
    for r in rows:
        original=names[r['订单行编号']].strip()
        enriched=inferred['mapping'].get(r['订单行编号'],{'原合并客户名称':original,'客户网名':'','合并客户名称':original or '合并客户未提供','合并名称来源':'原表' if original else '待核对','合并名称依据':'原始合并名称'})
        assert enriched['原合并客户名称']==original,'名称来源版本不一致，停止更新'
        r.update(enriched)
    # 当前文件每一行是唯一飞书记录的有符号金额。先聚合为订单，再挂商品；
    # 不把某一行成本复制成整单成本。无订单号使用独立来源行主键。
    groups=defaultdict(list)
    for r in rows:
        oid=r['订单编号'].strip() or '缺订单号:'+r['订单行编号']
        sign='退单' if Decimal(r['净收入（元）'])<0 else '正向或零额'
        groups[(oid,r['购买日期'],r['渠道'],r['客户编号'],sign,r['合并客户名称'])].append(r)
    output=[]
    for (oid,dt,original_ch,cid,sign,ch),group in groups.items():
        identity={f:' / '.join(sorted({r.get(f,'') for r in group if r.get(f)})) for f in ['客户网名','原合并客户名称','合并名称来源','合并名称依据']}
        # 区分日期/渠道/客户冲突时保留子交易，不覆盖同名订单。
        transaction=oid+'#'+hashlib.sha256((dt+'|'+original_ch+'|'+cid+'|'+sign+'|'+ch).encode()).hexdigest()[:12]
        revenue=sum(Decimal(x['净收入（元）']) for x in group)
        cost=sum(Decimal(x['原始财务成本总金额'] or x['净商品成本（元）']) for x in group)
        output.append({'记录类型':'订单','日期':dt,'渠道':ch,'合并客户名称':ch,'原经营渠道':original_ch,**identity,'订单编号':transaction,'客户编号':cid,
                       '客户类型':'身份待核实','总销额':str(revenue),'财务成本总金额':str(cost),
                       '订单状态':group[0]['订单状态'],'业务单元':group[0]['业务单元'],
                       '地区':group[0]['所属区域'],'金额依据':'来源逐行金额合计；源订单号='+oid})
        for r in group:
            output.append({'记录类型':'商品','日期':dt,'渠道':ch,'合并客户名称':ch,'原经营渠道':original_ch,**{f:r.get(f,'') for f in identity},'订单编号':transaction,
                           '订单行编号':r['订单行编号'],'商品编码':r['商品编号'],
                           '商品名称':r['商品名称'],
                           '数量':r['净件数'],'总销额':r['净收入（元）'],
                           '财务成本总金额':r['净商品成本（元）'],'业务单元':r['业务单元'],
                           '金额依据':'来源商品行实际值；品类、规格及促销机制未提供'})
    meta={'name':path.name,'kind':'local-reviewed-export','revision':3672,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
          'sourceRows':len(rows),'coverage':'已导出的飞书快照，未在本轮重新读取飞书',
          'grain':'唯一飞书记录的金额合计为交易；商品金额单独保留，不重复计入财务总额',
          'warning':'客户身份待核实；来源无订单号的记录仅用于财务，不用于购买次数。',
          'groupingField':'合并客户名字（展示名：合并客户名称）','customerNames':mapping_manifest,
          'nameMapping':'按飞书记录编号回连；金额仍为3672快照。只补原合并名称空值，网名推断与原表分别标记，不补造客户编号。',
          'nameInference':inferred['manifest']}
    return output,meta

def validate(records):
    orders=[];items=[];campaign=[];errors=[];excluded=Counter();keys=set(); adjustments=0
    if len(records)>400000: raise ValueError('一次最多导入40万行')
    for idx,r0 in enumerate(records,2):
        r={str(k).strip():str(v if v is not None else '').strip() for k,v in r0.items()}
        if not any(r.values()): continue
        try:
            typ=r.get('记录类型'); dt=day(r.get('日期'))
            if typ not in ['订单','商品','渠道日']: raise ValueError('记录类型须为订单、商品或渠道日')
            if not dt: raise ValueError('缺日期')
            if not dt.startswith('2026-'): excluded['非2026年']+=1;continue
            if typ in ['订单','商品'] and not r.get('业务单元'): excluded['业务单元空']+=1;continue
            if typ in ['订单','商品'] and r.get('业务单元')=='不计算销量': excluded['不计算销量']+=1;continue
            if typ in ['订单','商品'] and not any(token in r.get('业务单元','') for token in ['大客户','大单品','线下闭环']):
                excluded['业务单元不包含大客户、大单品或线下闭环']+=1;continue
            if typ in ['订单','商品'] and '2026-01'<=r.get('交易日期',dt)[:7]<='2026-06' and r.get('26年7月对应大区')=='线上分销':
                excluded['1—6月线上分销（交易日期）']+=1;continue
            oid=r.get('订单编号','')
            if typ=='订单':
                if not oid: raise ValueError('订单记录缺订单编号')
                key=(typ,oid)
            elif typ=='商品':
                if not oid or not r.get('订单行编号'): raise ValueError('商品记录缺关联订单编号或订单行编号')
                key=(typ,oid,r['订单行编号'])
            else:
                if not r.get('渠道'): raise ValueError('渠道日记录缺渠道')
                key=(typ,dt,r['渠道'],r.get('广告产品',''),r.get('投放计划',''))
            if key in keys: raise ValueError('主键重复，禁止自动合并或翻倍')
            keys.add(key)
            channel=(r.get('合并客户名称') or '合并客户未提供') if '合并客户名称' in r else (r.get('渠道') or '渠道未提供')
            rec={**r,'日期':dt,'渠道':channel}
            numeric=['数量','总销额','财务成本总金额','标价单价'] if typ!='渠道日' else FIELDS[FIELDS.index('归因首购净收入'):FIELDS.index('归因口径说明')]
            for f in numeric: rec[f]=num(r.get(f))
            if typ in ['订单','商品'] and (r.get('渠道产品类型')=='IP联名产品' or channel=='联名客户'):
                rec.update({'渠道':'联名客户','合并客户名称':'联名客户','渠道产品类型':'IP联名产品','利润处理':'不计算利润',
                            '来源财务成本总金额':r.get('来源财务成本总金额') or r.get('财务成本总金额',''),'财务成本总金额':None})
            if typ=='订单':
                if rec['总销额'] is None: raise ValueError('订单缺总销额，未知金额不能视为0')
                rec['原始成本']=rec['财务成本总金额']
                if rec['总销额']==0 and rec.get('订单状态')=='退货订单' and rec.get('利润处理')!='不计算利润': rec['财务成本总金额']=0; adjustments+=1
                orders.append(rec)
            elif typ=='商品': items.append(rec)
            else:
                for f in ['广告费','人工费','佣金','坑位费','样品成本','其他渠道费用','获客费用','首次付费新客数','曝光次数','点击次数','访客人数','加购人数','支付人数']:
                    if rec[f] is not None and rec[f]<0: raise ValueError(f'{f}不能为负')
                if any(rec.get(f) is not None for f in ['归因首购净收入','归因复购净收入','归因扩散复购净收入']) and not rec.get('归因口径说明'):
                    raise ValueError('有归因收入时须填写归因口径说明，确认三类收入互斥、渠道无重复')
                campaign.append(rec)
        except ValueError as exc: errors.append({'行号':idx,'问题':str(exc)})
    ordermap={r['订单编号']:r for r in orders}
    for r in items:
        o=ordermap.get(r['订单编号'])
        if not o: errors.append({'行号':r.get('订单行编号'),'问题':'商品关联订单不存在或被排除'})
        elif o['日期']!=r['日期'] or o['渠道']!=r['渠道']: errors.append({'行号':r['订单行编号'],'问题':'商品日期或渠道与订单不一致'})
        elif o['总销额']==0 and o.get('订单状态')=='退货订单' and r.get('财务成本总金额'):
            r['财务成本总金额']=None  # 整单豁免无法直接推断每条商品的成本调整。
    # 明细有完整金额时必须与订单一致；不完整时保留未知，禁止按件数悄悄分摊。
    byorder=defaultdict(list)
    for r in items: byorder[r['订单编号']].append(r)
    for oid,lines in byorder.items():
        if oid not in ordermap: continue
        for f in ['总销额','财务成本总金额']:
            if all(r.get(f) is not None for r in lines) and ordermap[oid].get(f) is not None:
                if abs(total(lines,f)-ordermap[oid][f])>.02:
                    # 成本归零特例允许商品保留源成本，但不当作实际商品毛利。
                    if f=='财务成本总金额' and ordermap[oid]['总销额']==0 and ordermap[oid].get('订单状态')=='退货订单': continue
                    errors.append({'行号':oid,'问题':f+'：商品合计与订单不一致'})
    if errors: raise ValueError(json.dumps({'错误数':len(errors),'示例':errors[:12]},ensure_ascii=False))
    if not orders: raise ValueError('没有可纳入的2026年订单记录')
    return orders,items,campaign,{'排除记录':dict(excluded),'成本归零订单':adjustments,'订单数':len(orders),'商品行数':len(items),'渠道日数':len(campaign)}

def customer_metrics(orders,items,cutoff):
    positive=[{**r,'日期':r.get('交易日期') or r['日期']} for r in orders if r['总销额']>0 and r.get('客户编号') and not r['订单编号'].startswith('缺订单号:') and (r.get('交易日期') or r['日期'])<=cutoff.isoformat()]
    customers=defaultdict(list)
    for r in positive: customers[r['客户编号']].append(r)
    out=[];cohorts=[];events={}
    cat_byorder=defaultdict(set)
    for r in items:
        if r.get('品类'): cat_byorder[r['订单编号']].add(r['品类'])
    for cid,rows in customers.items():
        rows.sort(key=lambda x:(x['日期'],x['订单编号']))
        dates=sorted(set(r['日期'] for r in rows)); gaps=[(date.fromisoformat(b)-date.fromisoformat(a)).days for a,b in zip(dates,dates[1:])]
        near=(cutoff-date.fromisoformat(dates[-1])).days; gap=max(gaps) if gaps else None
        types=set(r.get('客户类型','') for r in rows)
        typ='终端消费者' if types and types<={'终端消费者','消费者'} else '渠道客户' if types and types<={'渠道客户','经销商'} else '身份待核实'
        out.append({'客户编号':cid,'合并客户名称':' / '.join(sorted({r['渠道'] for r in rows})),
                    '客户网名':' / '.join(sorted({r.get('客户网名') for r in rows if r.get('客户网名')})),
                    '合并名称来源':' / '.join(sorted({r.get('合并名称来源') or '导入底表' for r in rows})),
                    '客户类型':typ,'有效交易数':len(rows),'购买天数':len(dates),
                    '首见日期':dates[0],'末购日期':dates[-1],'距末购天数':near,'历史最大间隔天数':gap,
                    '交易金额':total(rows,'总销额'),'间隔状态':'仅一个购买日，无法判断' if gap is None else '超过历史间隔' if near>gap else '未超过历史间隔',
                    '已购品类数':len(set().union(*(cat_byorder[r['订单编号']] for r in rows)))})
        events[cid]={'rows':rows,'dates':dates}
    for window in [30,60,90]:
        for month in sorted(set(v['dates'][0][:7] for v in events.values())):
            group=[v for v in events.values() if v['dates'][0].startswith(month)]
            mature=[v for v in group if (cutoff-date.fromisoformat(v['dates'][0])).days>=window]
            repeat=sum(any(0<(date.fromisoformat(d)-date.fromisoformat(v['dates'][0])).days<=window for d in v['dates'][1:]) for v in mature)
            cohorts.append({'首见月份':month,'窗口天数':window,'首见客户数':len(group),'成熟客户数':len(mature),'复购客户数':repeat,
                            '未满观察窗':len(group)-len(mature),'复购率':ratio(repeat,len(mature))})
    # A首次购买后90日内任意后续B；分母只包含A首次出现后满90天的客户。
    category_events=defaultdict(lambda:defaultdict(set))
    for cid,v in events.items():
        for r in v['rows']:
            category_events[cid][r['日期']].update(cat_byorder[r['订单编号']])
    categories=sorted(set(c for days in category_events.values() for cats in days.values() for c in cats))
    cells=[]
    for a in categories:
        eligible=[]
        for cid,days in category_events.items():
            a_dates=[d for d,cats in days.items() if a in cats]
            if not a_dates: continue
            first=min(a_dates)
            if (cutoff-date.fromisoformat(first)).days>=90: eligible.append((cid,first))
        for b in categories:
            count=sum(any(b in cats and 0<(date.fromisoformat(d)-date.fromisoformat(first)).days<=90 for d,cats in category_events[cid].items()) for cid,first in eligible)
            cells.append({'先购品类':a,'后购品类':b,'成熟客户数':len(eligible),'后续购买人数':count,'后购概率':ratio(count,len(eligible))})
    out.sort(key=lambda x: (x['间隔状态']!='超过历史间隔',-x['交易金额']))
    return out,cohorts,cells,events

COST_FIELDS=['广告费','人工费','佣金','坑位费','样品成本','其他渠道费用']
REVENUE_FIELDS=['归因首购净收入','归因复购净收入','归因扩散复购净收入']

def channel_metrics(rows):
    byday=defaultdict(list)
    for r in rows: byday[r['日期']].append(r)
    daily=[]
    for dt,group in sorted(byday.items()):
        complete=all(all(r.get(f) is not None for f in COST_FIELDS+REVENUE_FIELDS) for r in group)
        cost=sum(total(group,f) for f in COST_FIELDS) if complete else None
        revenue=sum(total(group,f) for f in REVENUE_FIELDS) if complete else None
        daily.append({'日期':dt,'归因收入':revenue,'全渠道费用':cost,'日ROI':ratio(revenue,cost) if complete else None})
    complete=bool(rows) and all(all(r.get(f) is not None for f in COST_FIELDS+REVENUE_FIELDS) for r in rows)
    cost=sum(total(rows,f) for f in COST_FIELDS) if complete else None
    revenue=sum(total(rows,f) for f in REVENUE_FIELDS) if complete else None
    rois=[r['日ROI'] for r in daily if r['日ROI'] is not None]
    var=statistics.pvariance(rois) if len(rois)>=2 else None
    cac_ok=bool(rows) and all(r.get('获客费用') is not None and r.get('首次付费新客数') is not None for r in rows)
    cac=ratio(total(rows,'获客费用'),total(rows,'首次付费新客数')) if cac_ok else None
    funnel=[]
    for field in ['曝光次数','点击次数','访客人数','加购人数','支付人数']:
        known=bool(rows) and all(r.get(field) is not None for r in rows)
        funnel.append({'环节':field,'数值':total(rows,field) if known else None,'单位':'次数' if field in ['曝光次数','点击次数'] else '人次（逐日求和）'})
    cpc=ratio(total(rows,'广告费'),total(rows,'点击次数')) if rows and all(r.get('广告费') is not None and r.get('点击次数') is not None for r in rows) else None
    result={'全成本ROI':ratio(revenue,cost) if complete else None,'全渠道费用':cost,'归因收入':revenue,'有效日数':len(rois),
            '日ROI均值':statistics.mean(rois) if rois else None,'日ROI总体方差':var,
            '课程稳定性比值':statistics.mean(rois)/var if var and len(rois)>=2 else None,'获客成本CAC':cac,'单次点击费用CPC':cpc,
            '资料状态':'费用与归因完整' if complete else '缺少费用或归因数据'}
    return result,daily,funnel

def financial_metrics(orders):
    sales=total(orders,'总销额')
    eligible=[r for r in orders if r.get('利润处理')!='不计算利润' and r.get('渠道')!='联名客户']
    profit_sales=total(eligible,'总销额');complete=bool(eligible) and all(r['财务成本总金额'] is not None for r in eligible)
    cost=total(eligible,'财务成本总金额') if complete else None
    positive=[r for r in orders if r['总销额']>0]; returns=[r for r in orders if r['总销额']<0]
    return {'净销售额':sales,'财务成本':cost,'毛利额':profit_sales-cost if complete else None,'毛利率':ratio(profit_sales-cost,profit_sales) if complete else None,
            '利润分析销售额':profit_sales,'不计利润销售额':sales-profit_sales,'不计利润交易数':len(orders)-len(eligible),
            '正向销售额':total(positive,'总销额'),'退单金额':total(returns,'总销额'),'退单笔数':len(returns),
            '交易笔数':len(orders),'成本缺失笔数':sum(r['财务成本总金额'] is None for r in eligible),
            '合并客户名称未提供金额':total([r for r in orders if r.get('渠道')=='合并客户未提供'],'总销额'),
            '有客户编号笔数':sum(bool(r.get('客户编号')) for r in orders),
            '客户编号覆盖率':ratio(sum(bool(r.get('客户编号')) for r in orders),len(orders))}

def build_snapshot(records,meta,view=None):
    orders,items,campaign,audit=validate(records)
    cutoff=date.fromisoformat(view['end'] if view else max(r['日期'] for r in orders))
    scopes=[ALL]+sorted(set(r['渠道'] for r in orders+campaign))
    if view:scopes=list(dict.fromkeys([ALL,view.get('scope',ALL)]))
    datasets={k:[] for k in ['finance','monthly','channels','customers','cohorts','matrix','campaign','daily_roi','funnel','products','readiness']}
    def push(key,scope,rows): datasets[key].extend({'范围':scope,**r} for r in rows)
    for scope in scopes:
        oscope=orders if scope==ALL else [r for r in orders if r['渠道']==scope]
        iscope=items if scope==ALL else [r for r in items if r['渠道']==scope]
        cscope=campaign if scope==ALL else [r for r in campaign if r['渠道']==scope]
        if not oscope:
            metrics=financial_metrics([])
        else: metrics=financial_metrics(oscope)
        clients,cohorts,matrix,_=customer_metrics(oscope,iscope,cutoff)
        metrics.update({'客户数':len(clients),'身份已确认消费者数':sum(c['客户类型']=='终端消费者' for c in clients),
                        '间隔可判断客户数':sum(c['历史最大间隔天数'] is not None for c in clients),
                        '超过历史间隔客户数':sum(c['间隔状态']=='超过历史间隔' for c in clients)})
        push('finance',scope,[metrics]);push('customers',scope,clients);push('cohorts',scope,cohorts);push('matrix',scope,matrix)
        for month in sorted(set(r['日期'][:7] for r in oscope)):
            rs=[r for r in oscope if r['日期'].startswith(month)]
            push('monthly',scope,[{'月份':month+'-01',**financial_metrics(rs)}])
        for channel in sorted(set(r['渠道'] for r in oscope)):
            rs=[r for r in oscope if r['渠道']==channel]
            push('channels',scope,[{'渠道':channel,**financial_metrics(rs)}])
        ch,days,funnel=channel_metrics(cscope)
        push('campaign',scope,[ch]);push('daily_roi',scope,days);push('funnel',scope,funnel)
        prods=defaultdict(list)
        for r in iscope:
            if r.get('商品编码'): prods[(r['商品编码'],r.get('规格','') or '规格未提供',r.get('促销机制','') or '机制未提供',r.get('数量单位','') or '单位未提供')].append(r)
        product_rows=[]
        for (sku,spec,mechanism,unit),rs in prods.items():
            complete=all(r.get('利润处理')!='不计算利润' and r.get('总销额') is not None and r.get('财务成本总金额') is not None for r in rs)
            qty=total(rs,'数量') if all(r.get('数量') is not None for r in rs) else None
            amount=total(rs,'总销额') if all(r.get('总销额') is not None for r in rs) else None
            product_rows.append({'商品编码':sku,'商品名称':' / '.join(sorted({r.get('商品名称','').strip() for r in rs if r.get('商品名称','').strip()})) or '商品名称未提供','规格':spec,'促销机制':mechanism,'数量单位':unit,'数量':qty,'明细净收入':amount,
                                 '明细毛利':amount-total(rs,'财务成本总金额') if complete else None,'商品行数':len(rs)})
        push('products',scope,sorted(product_rows,key=lambda x:-(x['明细净收入'] or 0)))
        consumer=sum(c['客户类型']=='终端消费者' for c in clients)
        ready=[
            {'分析环节':'销售与毛利','状态':'可分析' if metrics['财务成本'] is not None else '部分可分析','需要补充':'无' if metrics['财务成本'] is not None else '缺失的订单财务成本'},
            {'分析环节':'价格与促销','状态':'可模拟，实绩待比较','需要补充':'同商品、同规格的可比前后窗口；促销机制与新增费用'},
            {'分析环节':'渠道投放','状态':'可分析' if ch['全成本ROI'] is not None else '待补资料','需要补充':'六类全成本、三类互斥归因收入、归因说明；漏斗另需流量数据'},
            {'分析环节':'消费者复购','状态':'可分析' if consumer==len(clients) and consumer else '先核实客户身份','需要补充':'客户类型标记为终端消费者；2026年前历史未纳入，首见不等于真正首购'},
            {'分析环节':'跨品类推荐','状态':'可观察关联' if matrix else '待补资料','需要补充':'商品品类与稳定消费者编号；采用首购A后90天任意后购B的实施口径'},
            {'分析环节':'生存曲线','状态':'待确定事件时点','需要补充':'明确流失事件日期与右删失规则；现有间隔快照不能直接冒充生存曲线'},
            {'分析环节':'未来价值CLV','状态':'可申请本地训练' if consumer>=30 else '训练条件未满足','需要补充':'至少30位已确认消费者、10位重复购买者作为本应用运行门槛；另需训练诊断与留出回测'}]
        if scope=='联名客户':
            ready[0]={'分析环节':'销售与销量预测','状态':'可分析，不计算利润','需要补充':'月度净销量目标未提供，达成率留空；联名不参与财务对账'}
        push('readiness',scope,ready)
    provenance={
        'provider':'本地文件计算','tables':[meta['name']], 'executedAt':meta.get('readAt',now()),
        'files':[meta['name']], 'evidenceFlow':[{'title':'读取底表','detail':json.dumps(meta,ensure_ascii=False)},
          {'title':'经营范围','detail':'仅2026年发货；26年7月对应业务单元包含大客户、大单品或线下闭环。该字段为归属分类，不把日期限制到7月。先筛选业务单元，再排除1—6月交易日期且26年7月对应大区为线上分销的记录。IP联名单列联名客户，计销售不计利润。经营销售、费用联动和预算实际额按发货时间归月；缺发货时间才回退交易时间并标记。总销额只计订单记录一次。负金额为退单；零金额退货订单成本归零。'},
          {'title':'计算过程','detail':'decision-engine/engine.py：validate → financial_metrics / customer_metrics / channel_metrics → build_snapshot。经营月份按发货日期；客户行为保留交易日期，交易日期无效时回退发货日期，晚于观察截止的交易不计购买行为。客户按订单去重，复购按不同购买日；观察截止使用全部纳入订单的末日。'},
          {'title':'数据边界','detail':'本人本地使用，保留原始客户编号。最新版订单从用户工作簿只读提取，合并客户名称优先取原表，空值的网名唯一匹配另有状态与依据。客户未核实前不能解释为消费者。'}],
        'metricDefinitions':[
          {'label':'财务与毛利','definition':'净销售额为有符号订单金额之和，包含联名；成本与毛利只计非联名，毛利率分母也仅为非联名净销售额。联名不算利润且不参与财务对账。非联名源成本不全时不输出毛利。当前来源缺订单号的行生成独立计算记录，交易笔数并非均为可确认订单。','componentIds':['finance-strip','monthly-trend','channel-ranking']},
          {'label':'成熟窗口复购','definition':'分母为首见日距观察截止已满30/60/90天的客户；分子为首见后该窗口内不同日再次正向购买的客户。2026首见并非生命周期首购。','componentIds':['repeat-cohorts']},
          {'label':'个人历史购买间隔','definition':'距末购天数>相邻购买日的最大间隔时标记超过历史间隔；仅一次购买无法判定。这是课件快照规则，并非永久流失。','componentIds':['customer-risk']},
          {'label':'渠道全成本ROI','definition':'三类互斥归因收入之和/广告、人工、佣金、坑位、样品和其他费用之和。未知不按0补齐。稳定性按日ROI均值/总体方差，是实施参数选择。','componentIds':['campaign-efficiency','roi-trend']},
          {'label':'商品次购矩阵','definition':'A首次出现后满90天的客户为分母；A之后1至90天任意日购买B者为分子，同日不计。为实施补充，不声称视频已明确该窗口。','componentIds':['category-matrix']},
          {'label':'价格与促销','definition':'固定单位成本时，保原毛利总销量倍数=m/(m-d)，所需增幅=d/(m-d)；m>d才有有限解。课程例推导，模拟不是实际经营结果。','componentIds':['promotion-simulator']}]
    }
    old=_BROWSER_SNAPSHOT
    snapshot={'id':old['id'],'surface':'dashboard','title':'经营分析工作台','status':'authored','buildStatus':'complete','generatedAt':now(),
              'filters':[{'id':'scope','label':'合并客户名称','field':'范围','defaultValue':ALL}],
              'queries':{key:{'rows':rs,'source':dict(provenance)} for key,rs in datasets.items()},
              'businessContext':{'start':min(r['日期'] for r in orders),'end':cutoff.isoformat(),'source':meta,'audit':audit,'scopes':scopes,
                                 'sourceLineCount':meta.get('sourceRows',len(records)), 'inputRows':len(records)}}
    from financial_report import add_snapshot
    add_snapshot(snapshot,orders,ALL,limit_scopes=bool(view))
    if not view:
        from order_finance_reconciliation import add_snapshot as add_reconciliation_snapshot
        add_reconciliation_snapshot(snapshot)
        from customer_weekly import add_snapshot as add_weekly_snapshot
        add_weekly_snapshot(snapshot,orders,meta)
    from marketing_effect import add_snapshot as add_merged_products_snapshot
    add_merged_products_snapshot(snapshot,items,meta)
    from promotion_analysis import add_snapshot as add_promotion_snapshot
    add_promotion_snapshot(snapshot,orders,items)
    if not view:
        from collaboration_sales import add_snapshot as add_collaboration_snapshot
        add_collaboration_snapshot(snapshot,orders,items,meta)
    from dashboard_view import add_reading,options_from_rows,add_filter_definitions
    add_reading(snapshot,orders,items,view['start'] if view else snapshot['businessContext']['start'],cutoff.isoformat())
    if not view:
        from financial_report import load as load_financial
        snapshot['businessContext']['viewOptions']=options_from_rows(orders,load_financial()[0],items)
        add_filter_definitions(snapshot)
    return snapshot

def build_web():
    result=subprocess.run([str(NODE),str(BUILDER),'build','--project-dir',str(APP),'--separate-data'],capture_output=True,text=True,encoding='utf-8',errors='replace')
    if result.returncode and 'EPERM' in (result.stderr+result.stdout) and 'rename' in (result.stderr+result.stdout):
        # Windows目录替换偶尔遇到短暂文件锁；相同输入仅重试一次。
        result=subprocess.run([str(NODE),str(BUILDER),'build','--project-dir',str(APP),'--separate-data'],capture_output=True,text=True,encoding='utf-8',errors='replace')
    if result.returncode: raise RuntimeError(result.stderr[-4000:] or result.stdout[-4000:])
    return result.stdout[-2000:]

def save(records,meta,build=True):
    snapshot=build_snapshot(records,meta)
    LOCAL.mkdir(exist_ok=True)
    # 验收与构建失败时恢复当前数据，不破坏上一份可打开的页面。
    datafile=APP/'src/data.json'; previous=datafile.read_bytes()
    try:
        datafile.write_text(json.dumps(snapshot,ensure_ascii=False,allow_nan=False),encoding='utf-8')
        if build: build_web()
    except Exception:
        datafile.write_bytes(previous);raise
    (LOCAL/'current.json').write_text(json.dumps({'records':records,'meta':meta},ensure_ascii=False),encoding='utf-8')
    with (LOCAL/'统一底表_当前数据.csv').open('w',encoding='utf-8-sig',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=FIELDS,extrasaction='ignore');writer.writeheader();writer.writerows(records)
    return snapshot

def load_current(): return json.loads((LOCAL/'current.json').read_text(encoding='utf-8'))

def template_bytes():
    s=io.StringIO(); w=csv.writer(s);w.writerow(FIELDS);return ('\ufeff'+s.getvalue()).encode('utf-8')

if __name__=='__main__':
    records,meta=current_source();meta['readAt']=now()
    snap=save(records,meta,build='--no-build' not in sys.argv)
    print(json.dumps({'状态':'已计算','数据范围':snap['businessContext'],'经营合计':snap['queries']['finance']['rows'][0]},ensure_ascii=True))
