"""Sequential, isolated requests against the immutable published review bundle."""
import calendar,json,sys,gc
from pathlib import Path
from functools import lru_cache
import engine,dashboard_view,financial_population as fp

ROOT=Path(__file__).parent.parent
def unpack(p):return [dict(zip(p['keys'],r)) for r in p['rows']]
p=json.loads((ROOT/'records.json').read_text(encoding='utf-8'))
CURRENT={'meta':p['meta'],'records':unpack(p['data'])};del p
(ROOT/'records.json').unlink()
SNAPSHOT=json.loads((ROOT/'snapshot.json').read_text(encoding='utf-8'))
engine._BROWSER_SNAPSHOT=SNAPSHOT;dashboard_view._BROWSER_SNAPSHOT=SNAPSHOT
engine.load_current=lambda:CURRENT
OPTIONS=SNAPSHOT['businessContext']['viewOptions']
dashboard_view.options=lambda:OPTIONS
RECONCILIATION=None
import order_finance_reconciliation as reconciliation

def source_reconciliation(*args):
    # run() narrows lists in the returned dictionary; source rows stay immutable.
    global RECONCILIATION
    if RECONCILIATION is None:
        rp=json.loads((ROOT/'reconciliation.json').read_text(encoding='utf-8'))
        RECONCILIATION={**rp,'orders':unpack(rp['orders'])}
        (ROOT/'reconciliation.json').unlink()
    return {**RECONCILIATION,'orders':RECONCILIATION['orders'][:],'finance':RECONCILIATION['finance'][:]}

def reset():
    engine.load_current=lambda:CURRENT
    fp.ACTIVE_UNIT='';fp.ACTIVE_MONTHS=None;fp.ACTIVE_REGION='';fp.ACTIVE_PRODUCT=''
    for name in ['marketing_effect','expense_budget','expense_diagnostics','customer_weekly','collaboration_sales']:
        m=sys.modules.get(name)
        if m:
            for value in list(vars(m).values()):
                if hasattr(value,'cache_clear'):value.cache_clear()
    m=sys.modules.get('marketing_effect')
    if m:m.MONTHS=[f'2026-{i:02}' for i in range(1,10)]
    reconciliation.MONTHS=[f'2026-{i:02}' for i in range(1,10)]
    reconciliation.load=source_reconciliation

@lru_cache(maxsize=4)
def calculate(key):
    request=json.loads(key);path=request['path'];args=request.get('params',{})
    reset()
    if path=='/api/view-options':return json.dumps(OPTIONS,ensure_ascii=False)
    if path=='/api/model':return '{"predictions":[]}'
    if path=='/api/scenario':
        import promotion_analysis
        b=request['body'];return json.dumps(promotion_analysis.calculate(b['margin'],b['discount'],b['growth'],b.get('revenue')),ensure_ascii=False)
    allowed=['/api/dashboard-view','/api/marketing-effect','/api/order-finance-reconciliation','/api/customer-detail',
             '/api/customer-weekly','/api/expense-diagnostics','/api/collaboration-view','/api/collaboration-target']
    if path not in allowed:raise ValueError('网页分享版不执行文件导入或消费者模型训练')
    arg=lambda k,d='':args.get(k,[d])[0]
    unit=arg('businessUnit');unit='' if unit=='全部单元' else unit
    if unit and unit not in dashboard_view.UNITS:raise ValueError('业务单元选项无效')
    start,end=arg('shippingStart',OPTIONS['start']),arg('shippingEnd',OPTIONS['end'])
    if path in ['/api/customer-weekly','/api/expense-diagnostics','/api/collaboration-view','/api/collaboration-target']:
        start,end=OPTIONS['start'],OPTIONS['end']
    if not OPTIONS['start']<=start<=end<=OPTIONS['end']:raise ValueError('日期范围超出已发布数据覆盖期')
    scope=arg('scope',engine.ALL)
    if scope!=engine.ALL and scope not in OPTIONS['customers'][unit]:raise ValueError('所选客户不属于当前业务单元')
    result=dashboard_view.run({'path':path,'params':args,'unit':unit,'start':start,'end':end,'scope':scope})
    if path=='/api/dashboard-view':result['businessContext']['publicShare']=SNAPSHOT['businessContext']['publicShare']
    result_json=json.dumps(result,ensure_ascii=False,allow_nan=False,separators=(',',':'))
    del result;gc.collect()
    return result_json

def dispatch(raw):
    try:return json.dumps({'status':200,'data':json.loads(calculate(raw))},ensure_ascii=False,allow_nan=False,separators=(',',':'))
    except Exception as e:
        import traceback
        traceback.print_exc()
        return json.dumps({'status':400,'data':{'error':str(e)}},ensure_ascii=False)
