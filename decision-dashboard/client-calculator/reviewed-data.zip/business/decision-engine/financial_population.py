"""财务业务范围统一规则。"""
EXCLUDED={'易订货-含第五人格联名','易订货-含光夜二联'}
RULE='业务单元和大区两列均属于易订货-含第五人格联名或易订货-含光夜二联的行，排除财务收入、费用及利润；其他行不受此规则影响。'
# Non-default values are set only inside the isolated view worker, never in the HTTP process.
ACTIVE_UNIT=''
ACTIVE_MONTHS=None

def excluded(row):
    unit=str(row.get('业务单元','')).strip()
    return (unit in EXCLUDED and str(row.get('大区','')).strip() in EXCLUDED
            or bool(ACTIVE_UNIT and unit!=ACTIVE_UNIT)
            or ACTIVE_MONTHS is not None and row.get('月份','') not in ACTIVE_MONTHS)
