"""独立全量订单对账；不改变经营图表的发货口径，不摊派集团财务收入。"""
import csv, hashlib, json, unicodedata
from collections import Counter, defaultdict
from datetime import datetime
from decimal import Decimal
from functools import lru_cache
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import prepare_latest_orders as prep
from financial_population import excluded as finance_excluded,RULE as FINANCE_RULE
from inspect_latest_orders import NS, structure, strings, cells

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'订单财务对账_交易口径_20261021'
FINANCE=Path('C:/Users/87774/Desktop/财务经营报告.xlsx')
ALL='全部渠道'
MONTHS=[f'2026-{m:02}' for m in range(1,10)]
RULE='全量源商品行先取FA26年7月对应业务单元包含大客户、大单品或线下闭环，空单元全部排除；按P发货时间归月，累计BN总销额并保留负退单；再排除FH渠道产品类型=IP联名产品，以及发货月份1—6月EY26年7月对应大区=线上分销；重叠只扣一次。发货时间缺失不回退其他日期，不修改源日期。IP在经营看板单列联名客户，不参与对账；财务L最终收入保持原值。'
BASES={'shipping':('发货日期','发货月份（P发货时间）'),'transaction':('交易日期','下单月份（N交易时间）')}

def norm(v):return unicodedata.normalize('NFKC',str(v or '')).strip()
def dump(path,data):path.write_text(json.dumps(data,ensure_ascii=False,allow_nan=False,indent=2),encoding='utf-8')
def write_csv(path,rs):
    if not rs:return
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def dec(v):return prep.number(v)
def total(rs,field):
    values=[dec(r.get(field)) for r in rs];values=[v for v in values if v is not None]
    return float(sum(values,Decimal(0))) if values else None

def exclusion(r,basis='shipping'):
    if not any(t in r.get('26年7月对应业务单元','') for t in prep.TOKENS):return '业务单元不包含大客户、大单品或线下闭环'
    if norm(r.get('渠道产品类型'))=='IP联名产品':return 'IP联名产品'
    if '2026-01'<=r[BASES[basis][0]][:7]<='2026-06' and norm(r.get('26年7月对应大区'))=='线上分销':return '1—6月线上分销'
    return ''

def prepare():
    OUT.mkdir(exist_ok=True)
    hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (prep.SOURCE,FINANCE)}
    raw=list(prep.rows());aliases=defaultdict(set)
    for r in raw:
        if norm(r['客户网名']) and norm(r['合并客户名字']):aliases[norm(r['客户网名'])].add(norm(r['合并客户名字']))
    finances=[]
    with ZipFile(FINANCE) as z:
        ss=strings(z);sheet=next(s for s in structure(z) if s['name']=='客户维度')
        with z.open(sheet['path']) as f:
            for _,row in ET.iterparse(f,events=['end']):
                if row.tag!='{'+NS['m']+'}row':continue
                rn=int(row.get('r'));cs=cells([c for c in row if ''.join(x for x in c.get('r','') if x.isalpha()) in ('A','B','D','E','L')],ss)
                vals={k:v['value'] for k,v in cs.items()}
                if rn==3:assert {k:vals[k] for k in ('D','E','L')}=={'D':'合并客户名称','E':'月份','L':'最终收入'},vals
                if rn>=4 and norm(vals.get('E')) in {m.replace('-','') for m in MONTHS} and norm(vals.get('D')):
                    if cs.get('L',{}).get('type')=='e':raise ValueError(f'财务L{rn}错误')
                    period=norm(vals['E']);unit={'业务单元':norm(vals.get('A')),'大区':norm(vals.get('B'))}
                    finances.append({'月份':period[:4]+'-'+period[4:],'财务客户名称':norm(vals['D']),'原财务客户名称':vals['D'],'财务最终收入':vals.get('L',''),'财务来源行号':rn,**unit,'财务排除原因':FINANCE_RULE if finance_excluded(unit) else ''})
                row.clear()
    names={r['财务客户名称'] for r in finances if not r['财务排除原因']};merged={norm(r['合并客户名字']) for r in raw if norm(r['合并客户名字'])}
    owners={n:(n if n in merged else next(iter(aliases[n])) if len(aliases[n])==1 else n) for n in names}
    for r in finances:r['合并客户名称']=owners.get(r['财务客户名称'],r['财务客户名称'])
    for r in raw:
        nick=norm(r['客户网名']);original=norm(r['合并客户名字']);a=aliases[nick]
        group=original or (next(iter(a)) if len(a)==1 else '合并客户未提供')
        fin=nick if nick in names and nick!=group else group if group in names else nick if nick in names else ''
        r.update({'合并客户名称':group,'网名键':nick or '客户网名未提供','财务匹配名称':fin,'匹配依据':'客户网名与财务名称完全一致' if fin==nick else '原合并客户名称' if fin and original else '网名唯一映射合并客户' if fin else '财务无匹配名称',
                  '排除原因':exclusion(r),'现有经营排除原因':prep.reason(r)})
    for p,h in hashes.items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,'源文件读取中发生变化'
    meta={'executedAt':datetime.now().astimezone().isoformat(),'hashes':hashes,'orderRows':len(raw),'financeRows':len(finances),'rule':RULE,
          '产品类型分布':dict(Counter(r['渠道产品类型'] for r in raw)),'七月大区分布':dict(Counter(r['26年7月对应大区'] for r in raw)),'财务没有客户网名或产品类型明细':True}
    dump(OUT/'对账源数据.json',{'orders':raw,'finance':finances,'meta':meta})
    write_csv(OUT/'01_全量订单来源与排除标记.csv',raw)
    write_csv(OUT/'02_财务收入原行.csv',finances);dump(OUT/'manifest.json',meta)
    load.cache_clear()
    for scope,label in [(ALL,'全部客户'),('万辰集团','万辰集团')]:
        d=analyze(scope);write_csv(OUT/f'{label}_逐月差异.csv',d['月度']);write_csv(OUT/f'{label}_客户网名月度明细.csv',d['客户月度'])
    print(json.dumps(meta,ensure_ascii=False),flush=True)

@lru_cache(maxsize=1)
def load(stamp=None):
    data=json.loads((OUT/'对账源数据.json').read_text(encoding='utf-8'))
    financial_names={norm(r['财务客户名称']) for r in data['finance'] if not r.get('财务排除原因')}
    for r in data['finance']:r['合并客户名称']=norm(r['财务客户名称'])
    for r in data['orders']:
        r['排除原因']=exclusion(r);r['现有经营排除原因']=prep.reason(r)
        group=norm(r['合并客户名称'])
        r['财务匹配名称']=group if group in financial_names else ''
        r['匹配依据']='合并客户名称完全一致' if group in financial_names else '财务无同名合并客户'
    data['meta']['rule']=RULE
    return data

def analyze(scope=ALL,nickname='',population='full'):
    if scope=='联名客户':return {'月度':[],'客户月度':[],'排除明细':[],'客户网名选项':[],'说明':'联名客户不参与财务对账','来源':{},'源记录统计':{}}
    if population not in ('full','operating'):raise ValueError('未知订单范围')
    basis='shipping'
    date_field,date_label=BASES[basis]
    file=OUT/'对账源数据.json'
    if not file.exists():raise ValueError('请先完整提取对账源数据')
    d=load(file.stat().st_mtime_ns)
    # 每次请求独立派生排除标记，不能修改共享缓存，避免切换口径污染并发请求。
    raw=[{**r,'排除原因':exclusion(r,basis)} for r in d['orders']];fin=d['finance']
    scoped=[r for r in raw if scope==ALL or r['合并客户名称']==scope]
    os=[r for r in scoped if r[date_field][:7] in MONTHS]
    nicknames=sorted({r['网名键'] for r in os})
    if nickname and nickname not in nicknames:raise ValueError('该范围下没有此客户网名')
    if nickname:os=[r for r in os if r['网名键']==nickname]
    fs=[r for r in fin if not r.get('财务排除原因') and (scope==ALL or r['合并客户名称']==scope)]
    # 财务只在合并客户层计算，客户网名仅用于查看来源，不再匹配或分摊财务。
    fin_nicks=defaultdict(set)
    for r in raw:
        if r['财务匹配名称']:fin_nicks[r['财务匹配名称']].add(r['网名键'])
    if nickname:
        fs=[]
    months=[];details=[];excludes=[]
    for m in MONTHS:
        pre=[r for r in os if r[date_field].startswith(m)]
        unit_out=[r for r in pre if r['排除原因']=='业务单元不包含大客户、大单品或线下闭环']
        ip=[r for r in pre if r['排除原因']=='IP联名产品']
        online=[r for r in pre if r['排除原因']=='1—6月线上分销']
        scope_out=[r for r in pre if not r['排除原因'] and population=='operating' and r['现有经营排除原因']]
        kept=[r for r in pre if not r['排除原因'] and not(population=='operating' and r['现有经营排除原因'])]
        fm=[r for r in fs if r['月份']==m];order=total(kept,'总销额');income=total(fm,'财务最终收入')
        # 覆盖到此月但全部被显式过滤，是可核验的0；完全没有源记录则保持缺失。
        if pre and not kept:order=0.
        row={'合并客户名称':scope,'客户网名':nickname or '全部客户网名','月份':m,'范围口径':'全量订单' if population=='full' else '现有经营范围',
             '排除前订单总销额':total(pre,'总销额'),'业务单元排除金额':total(unit_out,'总销额') or 0.,'IP联名排除金额':total(ip,'总销额') or 0.,'1—6月线上分销排除金额':total(online,'总销额') or 0.,'经营范围额外排除金额':total(scope_out,'总销额') or 0.,
             '订单总销额':order,'财务最终收入':income,'订单减财务差额':float(Decimal(str(order))-Decimal(str(income))) if order is not None and income is not None else None,
             '纳入源商品行数':len(kept),'财务来源行数':len(fm),'未匹配财务订单金额':total([r for r in kept if not r['财务匹配名称']],'总销额'),
             '核对状态':'财务未拆到客户网名' if nickname and not fs else '比较已填金额；订单排除产品，财务未拆产品',
             '订单月份依据':date_label+'；不回退其他日期','销售来源字段':'BN总销额'}
        months.append(row)
        for group,n in sorted({(r['合并客户名称'],r['网名键']) for r in pre}):
            nr=[r for r in kept if r['网名键']==n and r['合并客户名称']==group];nr_pre=[r for r in pre if r['网名键']==n and r['合并客户名称']==group]
            one=[]
            a=total(nr,'总销额') if nr else 0.;b=total(one,'财务最终收入')
            details.append({'合并客户名称':group,'客户网名':n,'月份':m,'订单月份依据':date_label,'订单总销额':a,'IP联名排除金额':total([r for r in nr_pre if r['排除原因']=='IP联名产品'],'总销额') or 0.,
                '1—6月线上分销排除金额':total([r for r in nr_pre if r['排除原因']=='1—6月线上分销'],'总销额') or 0.,'财务最终收入':b,'订单减财务差额':a-b if b is not None else None,
                '财务匹配名称':' / '.join(sorted({r['财务匹配名称'] for r in nr_pre if r['财务匹配名称']})),
                '匹配依据':' / '.join(sorted({r['匹配依据'] for r in nr_pre})),'财务明细状态':'仅订单来源明细；财务按合并客户月汇总','纳入源商品行数':len(nr)})
        for r in unit_out+ip+online+scope_out:
            excludes.append({'订单月份依据':date_label,**{k:r.get(k,'') for k in ['交易日期','发货日期','订单编号','客户网名','合并客户名称','渠道产品类型','26年7月对应业务单元','26年7月对应大区','总销额','排除原因','现有经营排除原因','来源工作表','来源行号']}})
    return {'月度':months,'客户月度':details,'排除明细':excludes,'日期口径':basis,'月份依据':date_label,'客户网名选项':nicknames,'说明':RULE,'来源':{**d['meta'],'selectedDateBasis':date_label},
            '源记录统计':{'全部订单商品行':len(raw),'有效2026年1至9月商品行':sum(r[date_field][:7] in MONTHS for r in raw),'所选范围日期缺失行数':sum(not r[date_field] for r in scoped)}}

def add_snapshot(snapshot):
    if not (OUT/'对账源数据.json').exists():return
    result=analyze()
    current_hash=snapshot.get('businessContext',{}).get('source',{}).get('sha256')
    expected_hash=result['来源']['hashes'][str(prep.SOURCE)]
    stale=current_hash!=expected_hash
    source={'provider':'本地原工作簿完整只读提取','executedAt':result['来源']['executedAt'],'files':[prep.SOURCE.name,FINANCE.name],
            'evidenceFlow':[{'title':'全量来源及文件校验','detail':json.dumps(result['来源'],ensure_ascii=False)},{'title':'取数与排除','detail':RULE},{'title':'合并客户匹配','detail':'订单按合并客户名称、发货月份汇总所有网名的总销额，与财务D列合并客户名称、月份下的L列最终收入比较；只按标准化后完全相同的合并名称匹配。客户网名仅展示订单来源，财务不分摊到网名。'}],
            'metricDefinitions':[{'label':'发货月份与财务收入核对','definition':RULE+'差额=筛选后订单总销额−原财务最终收入。缺失保持null，财务收入只计一次。','componentIds':['report-reconciliation','report-reconciliation-nicknames','report-reconciliation-exclusions']}]}
    if stale:source['evidenceFlow'].append({'title':'来源版本不一致','detail':'当前经营数据已更新；全量原订单对账等待重新提取，暂不混用旧版本。'})
    snapshot['queries']['report_nickname_reconciliation']={'rows':[] if stale else result['月度'],'source':source}

if __name__=='__main__':prepare()
