"""只读预览最新订单工作簿结构，流式读取避免整本加载。"""
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import json,posixpath
SOURCE=Path('D:/BaiduNetdiskDownload/销售数据日追踪_旺店通全量数据源_每日自动导出表 (1).xlsx')
NS={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def structure(z):
    rels={x.get('Id'):x.get('Target') for x in ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))}
    out=[]
    for s in ET.fromstring(z.read('xl/workbook.xml')).findall('m:sheets/m:sheet',NS):
        target=rels[s.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')]
        out.append({'name':s.get('name'),'path':target.lstrip('/') if target.startswith('/') else posixpath.normpath('xl/'+target)})
    return out
def strings(z):
    return [''.join(x.itertext()) for x in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',NS)] if 'xl/sharedStrings.xml' in z.namelist() else []
def cells(row,ss):
    out={}
    for c in row:
        ref=c.get('r','');col=''.join(x for x in ref if x.isalpha());v=c.find('m:v',NS);v=v.text if v is not None else ''
        if c.get('t')=='s':v=ss[int(v)] if v else ''
        elif c.get('t')=='inlineStr':v=''.join(c.find('m:is',NS).itertext())
        out[col]={'value':v,'formula':c.find('m:f',NS) is not None,'type':c.get('t')}
    return out
if __name__=='__main__':
    with ZipFile(SOURCE) as z:
        ss=strings(z)
        for sheet in structure(z):
            sample=[]
            with z.open(sheet['path']) as handle:
                for _,row in ET.iterparse(handle,events=['end']):
                    if row.tag!=f"{{{NS['m']}}}row":continue
                    sample.append({'row':row.get('r'),'cells':cells(row,ss)});row.clear()
                    if len(sample)>=3:break
            print(json.dumps({'sheet':sheet,'xmlBytes':z.getinfo(sheet['path']).file_size,'preview':sample},ensure_ascii=False))
