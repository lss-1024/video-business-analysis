"""客户月财务作为独立来源；不向订单摊费用、不重复累加收入。"""
import csv,json
from collections import defaultdict
from decimal import Decimal
from pathlib import Path
from financial_population import excluded
ROOT=Path(__file__).parent.parent
DIR=ROOT/'财务底数据_2026'
AMOUNTS=['最终收入','最终成本','最终毛利','营销费用额合计','履约费用额','人员费用额','税费额（4%）','净利润']
FEES=['营销费用额合计','履约费用额','人员费用额','税费额（4%）']
def load():
    if not (DIR/'manifest.json').exists():return [],{}
    meta=json.loads((DIR/'manifest.json').read_text(encoding='utf-8'))
    rows=[r for r in csv.DictReader((DIR/'01_客户月财务底表.csv').open(encoding='utf-8-sig')) if not excluded(r)]
    for r in rows:
        for k in AMOUNTS:r[k]=float(r[k]) if r[k] else None
    return rows,meta
def sums(rows,key):
    values=[Decimal(str(r[key])) for r in rows if r.get(key) is not None]
    return float(sum(values,Decimal(0))) if values else None
def summary(rows):
    out={k:sums(rows,k) for k in AMOUNTS}
    out['营销费用率']=out['营销费用额合计']/out['最终收入'] if out['营销费用额合计'] is not None and out['最终收入'] is not None and out['最终收入']>0 else None
    out['收入营销费用倍数']=out['最终收入']/out['营销费用额合计'] if out['最终收入'] is not None and out['营销费用额合计'] is not None and out['营销费用额合计']>0 else None
    costs=[r['最终成本'] if r['最终成本'] is not None else r['最终收入']-r['最终毛利'] if r['最终收入'] is not None and r['最终毛利'] is not None else None for r in rows]
    out.update({'财务行数':len(rows),'合并客户数':len({r['合并客户名称'] for r in rows}),
                '成本原值缺失行数':sum(r['最终成本'] is None for r in rows),
                '可计算成本':float(sum(Decimal(str(v)) for v in costs if v is not None)) if any(v is not None for v in costs) else None,
                '成本推算行数':sum(r['最终成本'] is None and c is not None for r,c in zip(rows,costs)),
                '缺失金额单元格数':sum(r[k] is None for r in rows for k in ['最终收入','最终毛利',*FEES,'净利润']),
                '净利润率':out['净利润']/out['最终收入'] if out['净利润'] is not None and out['最终收入'] else None,
                '期间费用及税费':sum(out[k] for k in FEES if out[k] is not None) if any(out[k] is not None for k in FEES) else None})
    out['利润勾稽差额']=out['最终毛利']-out['期间费用及税费']-out['净利润'] if all(out[k] is not None for k in ['最终毛利','期间费用及税费','净利润']) else None
    out['原表成本已填合计']=out.pop('最终成本')
    return out
def add_snapshot(snapshot,orders,all_value,limit_scopes=False):
    orders=[r for r in orders if r.get('渠道')!='联名客户' and r.get('利润处理')!='不计算利润']
    rows,meta=load()
    if not rows:return
    names=set(r['合并客户名称'] for r in rows)
    if not limit_scopes:snapshot['businessContext']['scopes']=[all_value]+sorted((set(snapshot['businessContext']['scopes'])|names)-{all_value})
    # 金额来源与映射字段来源分别记录版本，避免把本轮名称刷新说成金额刷新。
    snapshot['businessContext']['financialReport']={k:v for k,v in meta.items() if k!='totals' and k!='coreFormulas'}
    qs={k:[] for k in ['report_finance','report_monthly','report_fees','report_customers','report_reconciliation','report_marketing_details','report_marketing_groups','report_expense_details']}
    # 明细先按名称与来源列聚合；同名差旅/招待科目仍按原表列分别保留。
    detail=defaultdict(lambda:defaultdict(lambda:{'sum':Decimal(0),'filled':0,'missing':0}))
    subjects={}
    with (DIR/'02_费用科目明细.csv').open(encoding='utf-8-sig') as handle:
        for r in csv.DictReader(handle):
            if excluded(r):continue
            if r['来源列']=='Z':continue
            col=r['来源列'];subjects[col]=(r['科目分组'],r['费用科目'])
            for name in [r['合并客户名称'],all_value]:
                d=detail[name][col]
                if r['金额']=='':d['missing']+=1
                else:d['sum']+=Decimal(r['金额']);d['filled']+=1
    for scope in snapshot['businessContext']['scopes']:
        selected=rows if scope==all_value else [r for r in rows if r['合并客户名称']==scope]
        if not selected:continue
        qs['report_finance'].append({'范围':scope,**summary(selected)})
        for month in sorted({r['月份'] for r in selected}):
            rs=[r for r in selected if r['月份']==month];amount=summary(rs)
            qs['report_monthly'].append({'范围':scope,'月份':month+'-01',**amount})
            os=[r for r in orders if r['日期'].startswith(month) and (scope==all_value or r['渠道']==scope)]
            order_revenue=float(sum(Decimal(str(r['总销额'])) for r in os)) if os else None
            qs['report_reconciliation'].append({'范围':scope,'月份':month,'订单总销额':order_revenue,'销售来源字段':'总销额','订单月份依据':'发货时间优先，缺失回退交易时间','财务最终收入':amount['最终收入'],
                '订单减财务差额':order_revenue-amount['最终收入'] if order_revenue is not None and amount['最终收入'] is not None else None,
                '核对状态':'范围或确认口径有差异，未强行对齐','财务来源行数':len(rs)})
        for fee in FEES:
            qs['report_fees'].append({'范围':scope,'费用类别':fee,'金额':sums(selected,fee),'空白行数':sum(r[fee] is None for r in selected)})
        groups=defaultdict(list)
        for r in selected:groups[r['合并客户名称']].append(r)
        for name,rs in groups.items():qs['report_customers'].append({'范围':scope,'合并客户名称':name,**summary(rs)})
        marketing_groups=defaultdict(list)
        for col,(group,subject) in subjects.items():
            d=detail[scope][col]
            row={'范围':scope,'科目分组':group,'费用科目':subject,'来源列':col,'金额':float(d['sum']) if d['filled'] else None,'已填行数':d['filled'],'未填行数':d['missing']}
            qs['report_expense_details'].append({**row,'费用大类':'营销费用' if col<='BE' else '履约费用'})
            if col>'BE':continue
            qs['report_marketing_details'].append(row);marketing_groups[group].append(row)
        for name,field,col in [('人员费用','人员费用额','R'),('税费','税费额（4%）','S')]:
            qs['report_expense_details'].append({'范围':scope,'费用大类':name,'科目分组':name,'费用科目':field,'来源列':field,'金额':sums(selected,field),'已填行数':sum(r[field] is not None for r in selected),'未填行数':sum(r[field] is None for r in selected)})
        for group,rs in marketing_groups.items():
            qs['report_marketing_groups'].append({'范围':scope,'科目分组':group,'金额':sums(rs,'金额'),'未填单元格数':sum(r['未填行数'] for r in rs)})
        subtotal=sum((d['sum'] for col,d in detail[scope].items() if col<='BE'),Decimal(0))
        qs['report_finance'][-1]['营销细项合计']=float(subtotal)
        qs['report_finance'][-1]['营销细项差额']=qs['report_finance'][-1]['营销费用额合计']-float(subtotal) if qs['report_finance'][-1]['营销费用额合计'] is not None else None
    source={'provider':'用户提供的本地财务工作簿','files':['财务经营报告.xlsx','财务底数据_2026/01_客户月财务底表.csv'],'tables':['客户维度'],
            'evidenceFlow':[{'title':'只读提取','detail':json.dumps(snapshot['businessContext']['financialReport'],ensure_ascii=False)},
                {'title':'金额口径','detail':f'客户维度第4行起，按月份202601至202609完整提取；原{meta.get("originalRows",meta["rows"])}行，业务单元与大区双列规则排除{meta.get("excludedRows",0)}行，纳入{len(rows)}行。'+meta.get('exclusionRule','')+'保留工作簿已存值及公式缓存；未重新计算整本工作簿。空白和横杠保留未知，汇总为已填金额合计。'},
                {'title':'避免重复','detail':'财务与订单分为独立查询，销售额不相加，费用不分摊至订单。订单销售额取总销额，经营月份按发货时间，缺失回退交易时间并标记。营销费用合计P为AA:BE共31项的合计；Z随车搭赠原表注明不计费用，单列保留。BF:BM为履约明细，不计入营销费用。明细与大类不重复相加。'},
                {'title':'营销费效边界','detail':'营销费用率=P/L；收入营销费用倍数=L/P，仅在分母为正且金额可用时计算。这是同期经营金额关系，不代表广告归因ROAS、增量ROI或获客CAC。六个科目组与31个科目按原表列聚合，空白保留未知。'},
                {'title':'质量边界','detail':'有26个辅助单元格公式错误，未参与本次核心金额提取；发现1条净利润勾稽差额0.18元，保留原值。1至8月原成本大量空白，可计算成本按收入减毛利推算并单独标记。'}],
            'metricDefinitions':[{'label':'财务经营利润','definition':'读取原表最终收入、最终毛利、营销/履约/人员费用、税费及净利润。净利润为原表运营净利润，非审计净利润；比例按汇总金额重算。','componentIds':['report-kpis','report-profit-trend','report-fees','report-customers','report-reconciliation']} ]}
    linked=[]
    monthly_lookup={(x['范围'],x['月份'][:7]):x for x in qs['report_monthly']}
    for r in qs['report_reconciliation']:
        monthly=monthly_lookup[(r['范围'],r['月份'])]
        linked.append({'范围':r['范围'],'月份':monthly['月份'],'费用金额':monthly['营销费用额合计'],'销售值':r['订单总销额']})
    qs['report_expense_sales_linkage']=linked
    linkage_source={**source,'files':source['files']+['财务底数据_2026/02_费用科目明细.csv',snapshot['businessContext']['source']['name']],
        'metricDefinitions':[{'label':'费用销售月度联动','definition':'Python按合并客户和月份关联全部、营销、履约、人员或税费与订单总销额，或按ED合并产品名字、同数量单位跨SKU汇总销量。明细AA:BM与P/Q/R/S合计由页面选择，Z不计费用。动态查询/api/marketing-effect返回完整9个月及缺失计数。Pearson同期、前月费用对次月销售、绝对变化相关；至少6个有效月份对、非零方差。仅描述联动，未控制混杂，不作因果或最优预算结论。','componentIds':['monthly-effect-stats','monthly-fee-sales-comparison','monthly-effect-table']},
        {'label':'费用稳定性与可选月份预算','definition':'expense_diagnostics.py按已填月份计算月均与CV。固定候选需9月有值、至少8月正支出、CV≤15%，合同尚待核实；履约细项未填全，预测使用Q总额。可选订单末月及之后两月。费用和未来整月销售使用1—9月完整月份，按对应步长滚动回测，至少3折，比较最近月、近3月均值、历史均值，按MAE选择水平基线。本月销售另用实际加余期周节奏估算。误差范围不是置信区间，选模误差非独立验证。当前费用尚缺，费用金额仍是历史基线，不输出实际费用率；预算费用率以当前预计发货销售为分母，不与财务收入分母混用。','componentIds':['expense-category-overview','expense-patterns','expense-fixed-candidates','expense-next-month-budget']},
        {'label':'本月实际加余期周节奏预测','definition':'month_nowcast.py：按发货日期计算本月实际总销额，余期从全表最新发货日次日至月底，未补齐日期也属估算期。9种候选包括近2/4完整周发货日均、近4周按星期发货、周下单趋势校正，以及客户下单日与金额、间隔与距上次下单、TSB发生概率与金额、近期28天采购变化及星期发货和客户周期等权组合。客户模型使用交易日期，按各客户可见的非负交易到发货天数中位数转换为发货节奏，并按56天日均负退单额调整；不代表完整待发订单池。下单趋势为近2完整周正交易金额/前2周，限0.5—1.5，无分母不调整；仅用当时已发货且交易时间不晚于当时的数据。过去相同月内日为截止，最多最近6个月、至少3个月回测选择余期MAE最小方法。本月整月销售=已发生+余期估算；费用率重新以此为分母。整月WAPE与余期WAPE分别计算；回测非独立验证，参考带不是置信区间，未覆盖未发货订单。','componentIds':['expense-next-month-budget','current-month-model-comparison']}]}
    linkage_source['metricDefinitions'].append({'label':'周月共享预测与重点客户分解','definition':'forecast_link.py共享周模型的未来逐日正下单额，剔除已发生和跨月部分；按84天可见金额加权发货延迟0—56天分布映射，并加56天负退单日均。周映射余期与原9法月度分支按2/3和1/3偏好权重组合，非最优权重。历史最近3个月同进度检验，月度分支每折仅用更早至少3折选模。全部客户按近3完整月正向发货累计80%最多10个合并客户分别预测，其余独立成组，日、周、月加和一致；当前分组选样条件下误差不代表独立组合验证。未确认真实待发池、客户库存或终端销量。','componentIds':['forecast-major-customers','forecast-week-month-bridge','expense-next-month-budget']})
    for k,v in qs.items():snapshot['queries'][k]={'rows':v,'source':linkage_source if k=='report_expense_sales_linkage' else source}
    import expense_budget
    expense_budget.add_snapshot(snapshot)
