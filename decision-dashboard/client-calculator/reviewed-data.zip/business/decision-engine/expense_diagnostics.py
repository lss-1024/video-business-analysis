"""短历史费用结构、描述性关联与可回测预算基线；不估计因果。"""
import csv,math,statistics
from functools import lru_cache
from datetime import date
import engine,financial_report,marketing_effect,month_nowcast
METHODS=('最近月延续','近3月均值','历史月均值')
def mean(xs):return sum(xs)/len(xs) if xs else None
def cv(xs):
    m=mean(xs)
    return statistics.pstdev(xs)/abs(m) if m and len(xs)>1 else None
def predict(values,method):
    if not values or any(x is None for x in values):return None
    if method=='最近月延续':return values[-1]
    if method=='近3月均值':return mean(values[-3:])
    return mean(values)
def forecast(values,horizon=1):
    # Same observed origin/target pairs for all candidate methods, strictly past-only.
    if len(values)<6 or any(x is None for x in values):return {'预测值':None,'状态':'完整月份不足；未将缺失补零','回测月数':0}
    scores=[]
    for method in METHODS:
        pairs=[(predict(values[:i],method),values[i+horizon-1]) for i in range(3,len(values)-horizon+1)]
        if len(pairs)<3:continue
        absolute=[abs(p-a) for p,a in pairs];den=sum(abs(a) for p,a in pairs)
        scores.append({'方法':method,'回测MAE':mean(absolute),'回测WAPE':sum(absolute)/den if den else None,'回测月数':len(pairs)})
    if not scores:return {'预测值':None,'状态':'可回测月份不足3个','回测月数':0}
    best=min(scores,key=lambda x:x['回测MAE']);value=predict(values,best['方法'])
    return {**best,'预测值':value,'参考下沿':max(0,value-best['回测MAE']) if min(values)>=0 else value-best['回测MAE'],'参考上沿':value+best['回测MAE'],'候选方法':scores,'状态':'水平基线；参考带为预测值±回测平均绝对误差，不是置信区间'}
@lru_cache(maxsize=1)
def catalog(stamp):
    by={}
    with (financial_report.DIR/'02_费用科目明细.csv').open(encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            if r['来源列']!='Z':by[r['来源列']]={'来源列':r['来源列'],'费用科目':r['费用科目'],'科目分组':r['科目分组'],'费用大类':'营销费用' if r['来源列']<='BE' else '履约费用'}
    by['人员费用额']={'来源列':'人员费用额','费用科目':'人员费用额','科目分组':'人员费用','费用大类':'人员费用'}
    by['税费额（4%）']={'来源列':'税费额（4%）','费用科目':'税费额（4%）','科目分组':'税费','费用大类':'税费'}
    return list(by.values())
def nature(name,group):
    if '历史' in group:return '历史调整，不作为可持续投放'
    if any(t in name for t in ['税','佣金','手续费']):return '可能随成交计提，需核对计提规则'
    if any(t in name for t in ['广告','投放','促销','陈列','搭赠','折扣','推广','激励']):return '可能通过触达或价格激励影响采购'
    if any(t in name for t in ['保险','审厂','行政','租','人员']):return '基础或合规投入，通常间接关联'
    return '需结合合同、活动时间和结算方式核实'
def analyze(scope,metric='总销额',sku='',target_month='',product='',unit=''):
    subjects=catalog((financial_report.DIR/'02_费用科目明细.csv').stat().st_mtime_ns)
    base=marketing_effect.analyze(scope)
    sales=[r['销售值'] for r in base['月度']]
    current=engine.load_current()
    allorders,_,_,_=engine.validate(current['records'])
    end=date.fromisoformat(current['meta'].get('viewObservationEnd') or max(r['日期'] for r in allorders))
    start_index=end.year*12+end.month-1
    available=[f'{i//12}-{i%12+1:02}' for i in range(start_index,start_index+3)]
    target=target_month or available[0]
    if target not in available:raise ValueError('预算月份仅支持订单最新月份及其后两个月')
    target_year,target_number=map(int,target.split('-'))
    horizon=(target_year-2026)*12+target_number-9
    horizon=max(1,horizon)
    sales_fit=forecast(sales,horizon)
    records=[];monthly=[]
    revenue=sum(sales) if all(v is not None for v in sales) else None
    for subject in subjects:
        result=marketing_effect.analyze(scope,subject['来源列'],metric,sku,product,unit)
        rows=result['月度'];values=[r['费用金额'] for r in rows];known=[v for v in values if v is not None]
        monthly.extend({**r,**subject,'范围':scope} for r in rows)
        avg=mean(known);spread=cv(known);positive=sum(v>0 for v in known)
        ratios=[r['费用金额']/s for r,s in zip(rows,sales) if r['费用金额'] is not None and s is not None and s>0]
        if len(known)<6:kind='资料不足'
        elif any(v<0 for v in known):kind='含冲回调整，需核对'
        elif len(known)==9 and all(v==0 for v in known):kind='已填值均为零'
        elif len(known)==9 and positive>=8 and spread is not None and spread<=.15:kind='固定金额候选'
        elif len(ratios)>=6 and cv(ratios) is not None and cv(ratios)<=.20 and cv([v for v in sales if v is not None]) is not None and cv([v for v in sales if v is not None])>=.10:kind='比例支出候选'
        else:kind='波动或阶段性支出'
        if '历史' in subject['科目分组']:kind='历史调整项'
        stats={r['比较方式']:r for r in result['联动指标']}
        sync=stats['同期联动']['相关系数'];lag=stats['费用与次月销售']['相关系数'];change=stats['月度变化联动']['相关系数']
        mechanism=nature(subject['费用科目'],subject['科目分组'])
        # Ranking only highlights consistent positive movement, never an incremental effect.
        score=(max(change or 0,0)*.5+max(lag or 0,0)*.3+max(sync or 0,0)*.2)
        relevant='可能通过触达' in mechanism
        priority='优先核查' if relevant and change is not None and change>=.3 and (lag or 0)>=.3 else '可核查联动' if relevant and score>=.25 else '未见一致线索'
        if '计提' in mechanism:priority='先核对随销计提'
        if '历史' in subject['科目分组']:priority='历史调整，单独核查'
        fit=forecast(values,horizon) if kind not in ['历史调整项','含冲回调整，需核对'] else {'预测值':None,'回测MAE':None,'状态':'历史或冲回调整不外推为持续支出'}
        records.append({**subject,'已填月份数':len(known),'未填单元格数':sum(r['费用未填行数'] for r in rows),'月均支出':avg,'月支出标准差':statistics.pstdev(known) if known else None,'费用波动系数':spread,'已填费用率':sum(known)/revenue if len(known)==9 and revenue and revenue>0 else None,'支出判断':kind,'同期相关':sync,'次月相关':lag,'变化相关':change,'核查优先级':priority,'业务逻辑':mechanism,'核查分数':score,'预测月份':target,'目标月费用估算':fit.get('预测值'),'回测MAE':fit.get('回测MAE'),'回测方法':fit.get('方法'),'回测月数':fit.get('回测月数',0),'预测状态':fit['状态'],'费用曲线':values})
    fixed=[r for r in records if r['支出判断']=='固定金额候选']
    fixed_month=sum(r['月均支出'] for r in fixed) if fixed else None
    costs=[];category_totals=[]
    for category,subject in [('营销费用','营销费用合计'),('履约费用','履约费用合计'),('人员费用','人员费用额'),('税费','税费额（4%）')]:
        month_rows=marketing_effect.analyze(scope,subject)['月度']
        vs=[r['费用金额'] for r in month_rows];known=[v for v in vs if v is not None]
        amount=sum(known) if known else None
        detail_amounts=[v for r in records if r['费用大类']==category for v in r['费用曲线'] if v is not None]
        detail_sum=sum(detail_amounts) if detail_amounts else None
        category_totals.append({'费用大类':category,'费用科目':subject,'来源列':{'营销费用':'P','履约费用':'Q','人员费用':'R','税费':'S'}[category],
                                '费用曲线':vs,'1—9月已填合计':amount,'月均支出':mean(known),'费用波动系数':cv(known),
                                '订单口径费用率':amount/revenue if amount is not None and revenue and revenue>0 and len(known)==9 else None,
                                '已填月份数':len(known),'未填单元格数':sum(r['费用未填行数'] for r in month_rows),
                                '已填细项合计':detail_sum,'合计减已填细项':amount-detail_sum if amount is not None and detail_sum is not None else None})
        costs.append({'费用类别':subject,**forecast(vs,horizon)})
    cost_complete=all(r['预测值'] is not None for r in costs)
    expense=sum(r['预测值'] for r in costs) if cost_complete else None
    expense_mae=sum(r.get('回测MAE') or 0 for r in costs) if cost_complete else None
    predicted=sales_fit['预测值'];rate=expense/predicted if expense is not None and predicted and predicted>0 else None
    seen=[r for r in allorders if (scope==engine.ALL or r['渠道']==scope) and r['日期'].startswith(target)]
    current_month=engine.total([r for r in allorders if (scope==engine.ALL or r['渠道']==scope) and r['日期'].startswith(end.isoformat()[:7])],'总销额')
    headline={'预测月份':target,'拟合截止月份':'2026-09','预测步数':horizon,'目标月总销额估算':predicted,'目标月费用估算':expense,'目标月费用率估算':rate,'固定金额候选数':len(fixed),'固定候选月均支出':fixed_month,'历史固定候选费用率':fixed_month*9/revenue if fixed_month is not None and revenue and revenue>0 else None,'目标月固定候选费用率':fixed_month/predicted if fixed_month is not None and predicted and predicted>0 else None,'费用完整估算类别数':sum(r['预测值'] is not None for r in costs),'总销额回测MAE':sales_fit.get('回测MAE'),'总销额回测WAPE':sales_fit.get('回测WAPE'),'总销额预测方法':sales_fit.get('方法'),'回测月数':sales_fit.get('回测月数',0),'销售参考下沿':sales_fit.get('参考下沿'),'销售参考上沿':sales_fit.get('参考上沿'),'费用参考下沿':max(0,expense-expense_mae) if expense is not None else None,'费用参考上沿':expense+expense_mae if expense is not None else None,'本月截至日':end.isoformat(),'本月已发生总销额':current_month}
    headline.update({'可选预测月份':available,'是否本月':target==end.isoformat()[:7],'目标月已发生总销额':engine.total(seen,'总销额') if seen else None,'本月基线差额':predicted-current_month if predicted is not None and target==end.isoformat()[:7] else None})
    rolling=None
    if headline['是否本月']:
        import forecast_link
        rolling=forecast_link.portfolio(allorders,end) if scope==engine.ALL else forecast_link.analyze(allorders,scope,end)
        if rolling['已采用']:
            predicted=rolling['整月销售估算']
            headline.update({'预测模式':'本月周节奏滚动估算','历史整月基线':sales_fit['预测值'],
                             '目标月总销额估算':predicted,'目标月费用率估算':expense/predicted if expense is not None and predicted>0 else None,
                             '目标月固定候选费用率':fixed_month/predicted if fixed_month is not None and predicted>0 else None,
                             '余期销售估算':rolling['剩余期间销售估算'],'剩余预测天数':rolling['预测天数'],
                             '预计区间开始日期':rolling['预计区间开始日期'],'预计区间结束日期':rolling['预计区间结束日期'],
                             '销售参考下沿':rolling['参考下沿'],'销售参考上沿':rolling['参考上沿'],
                             '总销额回测MAE':rolling['回测MAE'],'总销额回测WAPE':rolling['整月回测WAPE'],
                             '余期销售回测WAPE':rolling['余期回测WAPE'],'总销额预测方法':rolling['方法'],
                             '回测月数':rolling['回测月数'],'本月基线差额':predicted-current_month})
    # Estimate costs AFTER the final weekly/monthly sales choice. The old independent
    # amount forecasts remain a visible comparator, never the headline numerator.
    import expense_budget
    fee_sales=predicted;fee_low=headline['销售参考下沿'];fee_high=headline['销售参考上沿'];ip_forecast=0.
    if scope=='联名客户':fee_sales=fee_low=fee_high=None
    elif scope==engine.ALL:
        ip=[r for r in allorders if r.get('利润处理')=='不计算利润' or r['渠道']=='联名客户']
        if ip:
            if headline['是否本月']:
                ip_result=forecast_link.analyze(allorders,'联名客户',end)
                ip_forecast=ip_result.get('整月销售估算') if ip_result.get('已采用') else None
            else:
                ip_series=[engine.total([r for r in ip if r['日期'].startswith(f'2026-{m:02}')],'总销额') for m in range(1,10)]
                ip_forecast=forecast(ip_series,horizon).get('预测值')
            fee_sales=max(0,predicted-ip_forecast) if predicted is not None and ip_forecast is not None else None
            fee_low=max(0,fee_low-ip_forecast) if fee_low is not None and ip_forecast is not None else None
            fee_high=max(0,fee_high-ip_forecast) if fee_high is not None and ip_forecast is not None else None
    budget=expense_budget.analyze(scope,fee_sales,fee_low,fee_high,horizon,rolling if scope!=engine.ALL or not ip_forecast else None)
    old_costs=costs;costs=budget['费用类别预测']
    for c in costs:
        old=next(r for r in old_costs if r['费用类别']==c['费用类别'])
        c['原金额基线']=old['预测值'];c['较原基线变化']=c['预测值']-old['预测值'] if c['预测值'] is not None and old['预测值'] is not None else None
    complete=all(c['预测值'] is not None for c in costs)
    new_expense=expense_budget.total(c['预测值'] for c in costs) if complete else None
    headline.update({'原费用金额基线':expense,'原费用率基线':expense/fee_sales if expense is not None and fee_sales and fee_sales>0 else None,
                     '目标月费用估算':new_expense,'目标月费用率估算':new_expense/fee_sales if new_expense is not None and fee_sales and fee_sales>0 else None,
                     '费用率销售分母':fee_sales,'联名销售预测扣除':ip_forecast,'费用预测口径':'非联名预计销售额' if scope==engine.ALL else '当前合并客户预计销售额',
                     '费用参考下沿':expense_budget.total(c['参考下沿'] for c in costs) if complete else None,
                     '费用参考上沿':expense_budget.total(c['参考上沿'] for c in costs) if complete else None,
                     '费用完整估算类别数':sum(c['预测值'] is not None for c in costs),
                     '参考财务毛利率':budget['参考财务毛利率'],'参考财务毛利月份':budget['参考财务毛利月份']})
    priority_order={'优先核查':0,'可核查联动':1,'先核对随销计提':2,'未见一致线索':3,'历史调整，单独核查':4}
    return {**budget,'费用大类总览':category_totals,'范围':scope,'销售指标':metric,'商品编码':sku if not product else '', '合并产品名称':product,'数量单位':unit,'科目分析':sorted(records,key=lambda r:(priority_order[r['核查优先级']],-r['核查分数'])),'逐月明细':monthly,'预测汇总':headline,'费用类别预测':costs,'销售回测':sales_fit,'本月滚动估算':rolling,'说明':'月均与稳定性初筛仍按已填额；固定候选需合同核实。41项细项不与四大类重复相加。销售保留已核对的实际发货＋周月联动预测。'+budget['费用预测说明'],'方法参考':'https://otexts.com/fpp3/toolbox.html#time-series-cross-validation'}
