"""月度费用与销售的描述性联动；不估计因果效应或最优预算。"""
import csv,math,json
from collections import defaultdict
from decimal import Decimal
from functools import lru_cache
import engine,financial_report
from financial_population import excluded
MONTHS=[f'2026-{m:02}' for m in range(1,10)]

def catalog_from_items(items):
    groups={}
    for r in items:
        name=r.get('合并产品名称','').strip()
        if not name:continue
        unit=r.get('数量单位') or '原表单位未填'
        for scope in [r['渠道'],engine.ALL]:
            entry=groups.setdefault((scope,name,unit),{'范围':scope,'合并产品名称':name,'数量单位':unit,'codes':set(),'商品行数':0})
            entry['codes'].add(r.get('商品编码',''));entry['商品行数']+=1
    rows=[{**{k:v for k,v in r.items() if k!='codes'},'选择键':json.dumps([r['合并产品名称'],r['数量单位']],ensure_ascii=False,separators=(',',':')),'包含商品编码':' / '.join(sorted(r['codes'])),'包含商品编码数':len(r['codes'])} for r in groups.values()]
    return sorted(rows,key=lambda r:(r['范围'],r['合并产品名称'],r['数量单位']))

def add_snapshot(snapshot,items,meta):
    rows=catalog_from_items(items)
    source={**snapshot['queries']['products']['source']}
    source['evidenceFlow']=[*source.get('evidenceFlow',[]),{'title':'合并产品名称来源','detail':json.dumps(meta.get('mergedProductNames',{'sourceField':'导入底表合并产品名称','rule':'直接使用原值；不推测空名称'}),ensure_ascii=False)}]
    definition={'label':'合并产品销量','definition':'筛选直接使用原表ED合并产品名字（底表列：合并产品名称）；按合并客户范围、发货月份、合并产品名称和数量单位汇总源商品行数量，保留负退单。同名多个SKU合并，每行只计一次；单位不同分别筛选，名称缺失不猜测归类。费用为客户范围整项费用，未分摊到产品。','componentIds':['monthly-effect-stats','monthly-fee-sales-comparison','monthly-effect-table','expense-patterns']}
    source['metricDefinitions']=[*source.get('metricDefinitions',[]),definition]
    snapshot['queries']['merged_products']={'rows':rows,'source':source}
    coverage=[]
    for scope in snapshot['businessContext']['scopes']:
        rs=[r for r in items if scope==engine.ALL or r['渠道']==scope]
        coverage.append({'范围':scope,'商品行数':len(rs),'合并名称缺失行数':sum(not r.get('合并产品名称','').strip() for r in rs)})
    snapshot['queries']['merged_product_coverage']={'rows':coverage,'source':source}
    linkage=snapshot['queries'].get('report_expense_sales_linkage',{}).get('source')
    if linkage:
        linkage['evidenceFlow']=[*linkage.get('evidenceFlow',[]),source['evidenceFlow'][-1]]
        linkage['metricDefinitions']=[*linkage.get('metricDefinitions',[]),definition]
    weekly_source=snapshot['queries'].get('customer_weekly_reference',{}).get('source')
    if weekly_source:
        weekly_source['evidenceFlow']=[*weekly_source.get('evidenceFlow',[]),source['evidenceFlow'][-1]]
        weekly_source['metricDefinitions']=[*weekly_source.get('metricDefinitions',[]),{'label':'按合并产品筛选周下单与预测','definition':'按ED合并产品名字筛选源商品行，按订单关联键加总其BN总销额后重新计算客户周下单、8种预测逻辑及客户习惯；同单其他商品不计入。完整来源观察截止日保持不变。产品筛选只影响本周度分析，上方合并客户月度预算维持全部产品，不带入未筛选的月度联动销售。','componentIds':['customer-weekly-summary','customer-weekly-trend','customer-weekly-forecast','customer-weekly-customers','customer-weekly-detail','customer-weekly-models','customer-purchase-habits']}]
    if meta.get('mergedProductNames'):snapshot['businessContext']['source']['mergedProductNames']=meta['mergedProductNames']

def correlation(pairs):
    pairs=[(x,y) for x,y in pairs if x is not None and y is not None]
    count=len(pairs)
    if count<6:return {'相关系数':None,'有效月份对':count,'状态':'不足6对，仅显示趋势；6对是本应用展示门槛，并非统计显著性标准'}
    xs,ys=zip(*pairs);xm=sum(xs)/count;ym=sum(ys)/count
    xx=sum((x-xm)**2 for x in xs);yy=sum((y-ym)**2 for y in ys)
    if xx<=1e-18 or yy<=1e-18:return {'相关系数':None,'有效月份对':count,'状态':'费用或销售无变化，相关系数无定义'}
    return {'相关系数':max(-1.,min(1.,sum((x-xm)*(y-ym) for x,y in pairs)/math.sqrt(xx*yy))),'有效月份对':count,'状态':'描述性相关，未控制季节、价格、促销、铺货及需求变化'}

@lru_cache(maxsize=2)
def prepared(current_stamp,finance_stamp,detail_stamp):
    financial,_=financial_report.load()
    fees=defaultdict(lambda:{'sum':Decimal(0),'filled':0,'missing':0})
    def add(name,month,subject,value):
        for scope in [name,engine.ALL]:
            d=fees[(scope,month,subject)]
            if value is None or value=='':d['missing']+=1
            else:d['sum']+=Decimal(str(value));d['filled']+=1
    for row in financial:
        for subject,field in [('营销费用合计','营销费用额合计'),('履约费用合计','履约费用额'),('人员费用额','人员费用额'),('税费额（4%）','税费额（4%）')]:add(row['合并客户名称'],row['月份'],subject,row[field])
    for scope,month in {(scope,month) for scope,month,subject in fees}:
        ds=[fees[(scope,month,s)] for s in ['营销费用合计','履约费用合计','人员费用额','税费额（4%）']]
        fees[(scope,month,'全部费用合计')]={'sum':sum((d['sum'] for d in ds),Decimal(0)),'filled':sum(d['filled'] for d in ds),'missing':sum(d['missing'] for d in ds)}
    with (financial_report.DIR/'02_费用科目明细.csv').open(encoding='utf-8-sig') as handle:
        for row in csv.DictReader(handle):
            if excluded(row):continue
            if row['来源列']!='Z':add(row['合并客户名称'],row['月份'],row['来源列'],row['金额'])
    orders,items,_,_=engine.validate(engine.load_current()['records'])
    revenue=defaultdict(list);quantities=defaultdict(list);merged=defaultdict(list)
    for row in orders:
        for scope in [row['渠道'],engine.ALL]:revenue[(scope,row['日期'][:7])].append(row['总销额'])
    for row in items:
        for scope in [row['渠道'],engine.ALL]:
            unit=row.get('数量单位') or '原表单位未填'
            quantities[(scope,row['日期'][:7],row.get('商品编码',''))].append((row.get('数量'),unit))
            name=row.get('合并产品名称','').strip()
            if name:
                merged[(scope,row['日期'][:7],name,unit)].append(row.get('数量'))
    return fees,revenue,quantities,merged,catalog_from_items(items)

def data_prepared():
    return prepared((engine.LOCAL/'current.json').stat().st_mtime_ns,(financial_report.DIR/'01_客户月财务底表.csv').stat().st_mtime_ns,(financial_report.DIR/'02_费用科目明细.csv').stat().st_mtime_ns)

def product_choices(scope):
    return [r for r in data_prepared()[4] if r['范围']==scope]

def analyze(scope,subject='营销费用合计',metric='总销额',sku='',product='',unit=''):
    if subject not in ['全部费用合计','营销费用合计','履约费用合计','人员费用额','税费额（4%）']+['A'+chr(i) for i in range(65,91)]+['B'+chr(i) for i in range(65,78)]:raise ValueError('仅支持原表AA至BM费用明细与营销、履约、人员和税费合计')
    if metric not in ['总销额','商品销量']:raise ValueError('销售指标不支持')
    if metric=='商品销量' and not (sku or product):raise ValueError('请选择合并产品名称；同名同单位汇总，不同数量单位分别分析')
    fees,revenue,quantities,merged,catalog=data_prepared()
    rows=[]
    units=set();codes=''
    if metric=='商品销量':
        if product:
            matches=[r for r in catalog if r['范围']==scope and r['合并产品名称']==product]
            units={r['数量单位'] for r in matches}
            if not matches:raise ValueError('当前合并客户范围没有此合并产品名称')
            if not unit and len(units)==1:unit=next(iter(units))
            if unit not in units:raise ValueError('请选择该合并产品的数量单位；不同单位不直接相加')
            units={unit};codes=next(r['包含商品编码'] for r in matches if r['数量单位']==unit)
        else:
            units={u for (sc,month,code),vals in quantities.items() if sc==scope and code==sku for value,u in vals}
            if len(units)>1:raise ValueError('所选商品存在多种数量单位，不能直接相加；请先统一单位')
    for month in MONTHS:
        fee=fees.get((scope,month,subject),{'sum':Decimal(0),'filled':0,'missing':0})
        values=revenue.get((scope,month),[]) if metric=='总销额' else merged.get((scope,month,product,unit),[]) if product else [v for v,u in quantities.get((scope,month,sku),[])]
        known=[v for v in values if v is not None]
        value=float(sum((Decimal(str(v)) for v in known),Decimal(0))) if known and len(known)==len(values) else None
        rows.append({'月份':month+'-01','费用科目':subject,'销售指标':metric,'商品编码':sku if metric=='商品销量' and not product else '',
            '合并产品名称':product if metric=='商品销量' else '', '数量单位':next(iter(units)) if units else '', '包含商品编码':codes,
            '费用金额':float(fee['sum']) if fee['filled'] else None,'销售值':value,'费用已填行数':fee['filled'],'费用未填行数':fee['missing'],
            '销售来源行数':len(values),'数量未填行数':len(values)-len(known)})
    for i,row in enumerate(rows):
        previous=rows[i-1] if i else {}
        for field,prefix in [('费用金额','费用'),('销售值','销售')]:
            old=previous.get(field);new=row[field]
            row[prefix+'环比']=new/old-1 if old is not None and old>0 and new is not None else None
            row[prefix+'变化额']=new-old if old is not None and new is not None else None
    stats=[{'比较方式':'同期联动',**correlation([(r['费用金额'],r['销售值']) for r in rows])},
           {'比较方式':'费用与次月销售',**correlation([(a['费用金额'],b['销售值']) for a,b in zip(rows,rows[1:])])},
           {'比较方式':'月度变化联动',**correlation([(r['费用变化额'],r['销售变化额']) for r in rows])}]
    return {'范围':scope,'费用科目':subject,'销售指标':metric,'商品编码':sku if not product else '', '合并产品名称':product,'包含商品编码':codes,'数量单位':next(iter(units)) if units else '', '月度':rows,'联动指标':stats,
        '说明':'仅2026年1至9月。费用按财务表月份；销售按发货月份汇总原订单总销额，缺发货时间回退交易时间并标记；合并产品名称直接取原表ED合并产品名字，同名同数量单位的源商品行汇总并保留负退单，不同单位不混加；名称缺失不推测。没有记录为未知，未补零；相关基于已填值，费用未填可能改变结果。费用未分摊至单个产品，相关不代表因果，也不表示费用增加1元带来多少销售。'}
