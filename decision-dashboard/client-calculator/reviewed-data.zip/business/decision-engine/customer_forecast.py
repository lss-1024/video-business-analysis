"""客户采购节奏模型。金额预测不等于客户终端售出量，所有特征只使用截止日可见记录。"""
import statistics as st
from collections import defaultdict, Counter
from datetime import date, timedelta

BEHAVIOR=('客户下单星期与批次金额','客户补货间隔与距上次下单','间歇下单概率与金额（TSB）','近期采购变化校正')
WEEK_BASE=('最近完整周延续','近4完整周均值','近8完整周均值')
ENSEMBLE='周均值与客户周期等权组合'
REFERENCE='https://otexts.com/fpp3/practical.html#time-series-of-counts'

def dates(start,end):
    return [start+timedelta(days=i) for i in range(max(0,(end-start).days+1))]

def identity(r):
    cid=r.get('客户编号','');nick=r.get('客户网名','')
    key='编号:'+cid if cid else '网名:'+nick if nick else '未识别客户'
    # Never combine distinct merged customers simply because a nickname/ID recurs.
    return r['渠道'],key

def visible(rows,origin):
    return [r for r in rows if r['日期']<=origin.isoformat() and
            (r.get('交易日期') or r['日期'])<=origin.isoformat()]

def profiles(rows,origin):
    people=defaultdict(list)
    for r in visible(rows,origin):
        if r['总销额']>0:people[identity(r)].append(r)
    output=[]
    for (scope,key),rs in people.items():
        daily=defaultdict(float)
        for r in rs:daily[date.fromisoformat(r.get('交易日期') or r['日期'])]+=r['总销额']
        all_days=sorted(daily);start=max(all_days[0],origin-timedelta(days=83))
        ds=[d for d in all_days if d>=start];exposure=(origin-start).days+1
        recent=sorted(daily.items())[-13:]
        gaps=[(b[0]-a[0]).days for a,b in zip(recent,recent[1:])]
        median=st.median(gaps) if gaps else None
        age=(origin-all_days[-1]).days
        # Purchase-day amount, not an invented order count or retail selling price.
        size=st.mean([v for d,v in recent[-8:]])
        rate=len(ds)/exposure if ds else 0.
        weekday_n=Counter(d.weekday() for d in ds)
        weekday_exposure=Counter(d.weekday() for d in dates(start,origin))
        probabilities={i:(weekday_n[i]+2*rate)/(weekday_exposure[i]+2) for i in range(7)}
        # TSB: update occurrence probability every observed calendar day, amount only on purchase days.
        probability=1./exposure if ds else 0.;smooth_size=daily[ds[0]] if ds else 0.
        for d in dates(start,origin):
            event=float(d in daily);probability=.9*probability+.1*event
            if event:smooth_size=.9*smooth_size+.1*daily[d]
        last28=sum(v for d,v in daily.items() if origin-timedelta(days=27)<=d<=origin)
        prior28=sum(v for d,v in daily.items() if origin-timedelta(days=55)<=d<origin-timedelta(days=27))
        lag_values=[(date.fromisoformat(r['日期'])-date.fromisoformat(r.get('交易日期') or r['日期'])).days for r in sorted(rs,key=lambda r:r.get('交易日期') or r['日期'])]
        valid_lags=[v for v in lag_values if v>=0]
        lag=round(st.median(valid_lags[-20:])) if valid_lags else 0
        stability=st.pstdev(gaps)/st.mean(gaps) if gaps and st.mean(gaps)>0 else None
        habit='资料不足' if len(gaps)<3 else '接近每日' if median<=1 else '每2—3天' if median<=3 else '每4—7天' if median<=7 else '每8—14天' if median<=14 else '间隔超过两周'
        most=weekday_n.most_common(1)
        # Complete historical months, unlike an incomplete current month, are directly comparable.
        month_keys=[];y=origin.year;m=origin.month
        for _ in range(3):
            m-=1
            if m==0:y-=1;m=12
            month_keys.append(f'{y}-{m:02}')
        first_ship=min(r['日期'] for r in rs)
        comparable=[k for k in month_keys if first_ship<=k+'-01']
        shipping_by_month={k:sum(r['总销额'] for r in rs if r['日期'].startswith(k)) for k in month_keys}
        record={'合并客户名称':scope,'客户键':key,'客户编号':rs[-1].get('客户编号',''),
                '客户网名':' / '.join(sorted({r.get('客户网名','') for r in rs if r.get('客户网名')})) or '未提供',
                '分组依据':'客户编号' if key.startswith('编号:') else '客户网名分组' if key.startswith('网名:') else '身份未知',
                '近期有下单天数':len(ds),'下单周期判断':habit,'典型下单间隔天数':median,
                '下单间隔波动系数':stability,'距上次下单天数':age,'最近下单日':all_days[-1].isoformat(),
                '常用下单日':('周一','周二','周三','周四','周五','周六','周日')[most[0][0]] if most else '近期无下单',
                '常用日占下单日比例':most[0][1]/len(ds) if most else None,
                '近期单个下单日平均金额':size,'近28天下单金额':last28,'前28天下单金额':prior28,
                '近28天金额变化率':last28/prior28-1 if prior28>0 else None,
                '近3完整月可比月数':len(comparable),
                '近3完整月月均正向发货额':st.mean([shipping_by_month[k] for k in comparable]) if comparable else None,
                '本月正向发货额':sum(r['总销额'] for r in rs if r['日期'].startswith(origin.strftime('%Y-%m'))),
                '典型交易至发货天数':lag,'日期倒挂记录数':len(lag_values)-len(valid_lags),
                '采购节奏经过比例':age/median if median and len(gaps)>=3 else None,
                '补货节奏线索':'资料不足' if len(gaps)<3 else '超过典型周期，待核实' if age>median else '接近典型周期' if age>=median*.8 else '尚未到典型周期',
                '库存量':None,'终端售出量':None,
                '库存分析状态':'缺库存快照及终端出库数据，采购节奏不等于库存消化'}
        output.append({'record':record,'daily':daily,'gaps':gaps,'size':size,'rate':rate,
                       'weekday':probabilities,'probability':probability,'smooth_size':smooth_size,'age':age,'lag':lag})
    return output

def predict(rows,origin,horizon=35,shipping=False):
    """Returns date-aligned amounts; shipping mode shifts forecast purchase days by observed lag."""
    ps=profiles(rows,origin);future=dates(origin+timedelta(days=1),origin+timedelta(days=horizon))
    out={name:{d:0. for d in future} for name in BEHAVIOR}
    for p in ps:
        # Unknown identities remain in aggregate baselines; never model them as one person.
        if p['record']['分组依据']=='身份未知' or p['rate']==0:continue
        # Renewal convolution avoids repeatedly enumerating an expanding age-state distribution.
        counts=Counter(p['gaps'])
        def hazard(interval):
            return (counts[interval]+4*p['rate'])/(sum(n for g,n in counts.items() if g>=interval)+4)
        first=[];renewal=[];survival_first=survival_new=1.;expected=[]
        for t in range(1,horizon+1):
            a=hazard(p['age']+t);b=hazard(t)
            first.append(survival_first*a);renewal.append(survival_new*b)
            survival_first*=1-a;survival_new*=1-b
            expected.append(first[-1]+sum(expected[j]*renewal[t-j-2] for j in range(t-1)))
        prior=p['record']['前28天下单金额'];recent=p['record']['近28天下单金额']
        trend=max(.5,min(1.5,(recent/prior)**.5)) if prior>0 else 1.
        for index,d in enumerate(future):
            q=expected[index]
            target=d+timedelta(days=p['lag']) if shipping else d
            if target not in out[BEHAVIOR[0]]:continue
            out[BEHAVIOR[0]][target]+=p['weekday'][d.weekday()]*p['size']
            out[BEHAVIOR[1]][target]+=q*p['size']
            out[BEHAVIOR[2]][target]+=p['probability']*p['smooth_size']
            out[BEHAVIOR[3]][target]+=p['weekday'][d.weekday()]*p['size']*trend
    if shipping:
        known=visible(rows,origin)
        refund_daily=sum(r['总销额'] for r in known if r['总销额']<0 and r['日期']>=(origin-timedelta(days=55)).isoformat())/56
        for series in out.values():
            for d in future:series[d]+=refund_daily
    return out,ps

def weekly_models(rows,origin,horizon=28):
    behavior,ps=predict(rows,origin,horizon)
    last_sunday=origin-timedelta(days=origin.weekday()+1)
    daily=defaultdict(float)
    for r in visible(rows,origin):
        if r['总销额']>0:daily[date.fromisoformat(r.get('交易日期') or r['日期'])]+=r['总销额']
    for name,weeks in zip(WEEK_BASE,(1,4,8)):
        start=last_sunday-timedelta(days=weeks*7-1)
        rate=sum(v for d,v in daily.items() if start<=d<=last_sunday)/(7*weeks)
        behavior[name]={d:rate for d in dates(origin+timedelta(days=1),origin+timedelta(days=horizon))}
    behavior[ENSEMBLE]={d:(behavior[WEEK_BASE[1]][d]+behavior[BEHAVIOR[1]][d])/2 for d in behavior[WEEK_BASE[1]]}
    return behavior,ps

def sum_period(series,start,end):return sum(v for d,v in series.items() if start<=d<=end)

def weekly(rows,scope,cutoff,customer=''):
    rows=[r for r in rows if (scope=='全部渠道' or r['渠道']==scope) and (not customer or identity(r)[1]==customer)]
    current=cutoff-timedelta(days=cutoff.weekday())
    forecasts,ps=weekly_models(rows,cutoff)
    actual_visible=visible(rows,cutoff)
    observed=sum(r['总销额'] for r in actual_visible if r['总销额']>0 and (r.get('交易日期') or r['日期'])>=current.isoformat())
    current_profiles=[p['record'] for p in ps]
    distinct_days={r.get('交易日期') or r['日期'] for r in actual_visible if r['总销额']>0}
    mature=not customer or (len(distinct_days)>=4 and (cutoff-date.fromisoformat(min(distinct_days))).days>=56)
    cache={}
    result=[];comparison=[];tests=[]
    for h in range(4):
        start=current+timedelta(days=7*h);end=start+timedelta(days=6)
        pairs={name:[] for name in forecasts}
        for weeks_back in range(h+1,h+13):
            origin=cutoff-timedelta(days=7*weeks_back)
            if (origin-date(origin.year,1,1)).days<84:continue
            target_start=origin-timedelta(days=origin.weekday())+timedelta(days=7*h);target_end=target_start+timedelta(days=6)
            if target_end>=current:continue
            if origin not in cache:cache[origin]=weekly_models(rows,origin)[0]
            visible_then=visible(rows,origin)
            known=sum(r['总销额'] for r in visible_then if r['总销额']>0 and target_start.isoformat()<=(r.get('交易日期') or r['日期'])<=target_end.isoformat())
            truth=sum(r['总销额'] for r in actual_visible if r['总销额']>0 and target_start.isoformat()<=(r.get('交易日期') or r['日期'])<=target_end.isoformat())
            for name,series in cache[origin].items():
                predicted=known+sum_period(series,target_start,target_end)
                pairs[name].append((predicted,truth))
                tests.append({'预测步数':h+1,'方法':name,'拟合截止日期':origin.isoformat(),'周开始日期':target_start.isoformat(),
                              '周结束日期':target_end.isoformat(),'预测值':predicted,'实际值':truth})
        models=[]
        for name,series in forecasts.items():
            errors=[abs(p-a) for p,a in pairs[name]];den=sum(abs(a) for p,a in pairs[name])
            value=(observed if h==0 else 0)+sum_period(series,start,end)
            usable=len(errors)>=6 and sum(a>0 for p,a in pairs[name])>=3 and mature
            model={'预测步数':h+1,'周开始日期':start.isoformat(),'周结束日期':end.isoformat(),
                   '方法':name,'预测值':value if usable else None,'本周已发生额':observed if h==0 else 0,
                   '剩余期间预测值':sum_period(series,start,end),'回测MAE':st.mean(errors) if errors else None,
                   '回测WAPE':sum(errors)/den if den else None,'回测周数':len(errors)}
            models.append(model)
        eligible=[m for m in models if m['预测值'] is not None]
        best=min(eligible,key=lambda m:m['回测MAE']) if eligible else models[0]
        for m in models:m['是否采用']='已采用' if m['方法']==best['方法'] and eligible else '参考'
        comparison.extend(models)
        result.append({**best,'候选方法':models,'状态':'本周实际＋余日估算' if h==0 and eligible else '未来整周下单参考' if eligible else '历史或有效回测不足，暂不输出',
                       '参考下沿':max(observed if h==0 else 0,best['预测值']-best['回测MAE']) if eligible else None,
                       '参考上沿':best['预测值']+best['回测MAE'] if eligible else None})
    daily_rows=[]
    for week in result:
        if week['预测值'] is None:continue
        for d,v in forecasts[week['方法']].items():
            if week['周开始日期']<=d.isoformat()<=week['周结束日期']:
                daily_rows.append({'日期':d.isoformat(),'周开始日期':week['周开始日期'],'方法':week['方法'],'预计正向下单额':v})
    return {'周预测':result,'方法对照':comparison,'回测明细':tests,'每日预测':daily_rows,
            '客户习惯':sorted(current_profiles,key=lambda r:-r['近28天下单金额']),
            '数据截至日期':cutoff.isoformat(),
            '说明':'按合并客户及客户编号分组，缺编号用网名单列；未知身份仅留在总额基线。每天多笔采购合为一个下单日，间隔基于不同下单日。客户星期模型将84天发生频率向总体日频率收缩；周期模型结合最近12个间隔和距上次下单天数，使用带日频率先验的更新过程；TSB按日更新发生概率、仅下单日更新金额，平滑参数均为0.1。近期采购变化模型以最近28天对前28天金额比的平方根校正星期模型，限0.5—1.5倍，无可比基数不调整。另与最近1/4/8完整周均额及4周均额和周期模型的等权组合比较。当前周加已发生额；各步长在历史同一星期几截止，最多12折、至少6折，以MAE选方法。所有特征要求发货日和交易日不晚于当时截止，避免偷看后续发货记录。该数据只覆盖已发货订单，未来未发货订单及未来新客未覆盖；预测是采购金额，不是客户终端售出量。参考带为±历史MAE，非置信区间；回测用于选模，非独立验证。库存、动销需客户×商品×单位的库存与出库，不从采购额反推真实库存。',
            '方法参考':REFERENCE}
