"""按真实交易日期聚合客户周下单，独立于按发货月份统计的经营销售。"""
from collections import defaultdict
from datetime import date,timedelta
from decimal import Decimal
from functools import lru_cache
import engine
import json
from copy import deepcopy
import customer_forecast

def monday(d):return d-timedelta(days=d.weekday())
def week_label(d):
    end=d+timedelta(days=6)
    return f'{d.month}月{d.day}日—{end.month}月{end.day}日'

def prepare_orders(orders,meta,cutoff=None):
    # Full source extraction establishes the observation boundary, not the last order of a customer.
    read_day=date.fromisoformat(meta.get('readAt',date.today().isoformat())[:10])
    cutoff=cutoff or min(read_day,date.today(),date.fromisoformat(max(r['日期'] for r in orders)));first=date(2026,1,1)
    events=[];future=0;missing_date=0;zero=0
    for r in orders:
        raw=r.get('交易日期') or r['日期'];d=date.fromisoformat(raw)
        if not r.get('交易日期'):missing_date+=1
        if d>cutoff:future+=1;continue
        if d<first:continue
        amount=Decimal(str(r['总销额']))
        if amount<=0:zero+=1;continue
        cid=r.get('客户编号','');nick=r.get('客户网名','')
        key='编号:'+cid if cid else '网名:'+nick if nick else '未识别客户'
        oid=r.get('原订单编号') or r.get('订单编号','')
        known_order=bool(oid and not oid.startswith('缺订单号:'))
        events.append({'scope':r['渠道'],'date':d,'week':monday(d),'key':key,'cid':cid,'nick':nick,
                       'basis':'客户编号' if cid else '客户网名分组' if nick else '身份未知',
                       'amount':amount,'order':oid if known_order else '',
                       'source_rows':r.get('来源行号','')})
    return {'cutoff':cutoff,'first':first,'events':events,'future':future,'fallback':missing_date,'scopes':{r['渠道'] for r in orders},
            'excluded_nonpositive':zero,'meta':meta,'orders':orders}

@lru_cache(maxsize=1)
def prepared(stamp):
    current=engine.load_current();orders,items,_,_=engine.validate(current['records'])
    cutoff=date.fromisoformat(current['meta']['viewObservationEnd']) if current['meta'].get('viewObservationEnd') else None
    return {**prepare_orders(orders,current['meta'],cutoff),'items':items}

def product_orders(orders,items,product):
    """同单只汇总选中产品的源商品行，禁止复用含其他产品的整单金额。"""
    by_order=defaultdict(list)
    for r in items:
        if r.get('合并产品名称','').strip()==product:by_order[r['订单编号']].append(r)
    if not by_order:raise ValueError('合并产品名称不存在或原表未提供')
    result=[]
    for order in orders:
        rs=by_order.get(order['订单编号'])
        if not rs:continue
        if any(r.get('总销额') is None for r in rs):raise ValueError('所选产品明细总销额缺失，不能替换为整单金额')
        result.append({**order,'合并产品名称':product,'总销额':float(sum((Decimal(str(r['总销额'])) for r in rs),Decimal(0))),
                       '来源行号':','.join(str(r['来源行号']) for r in rs),'商品名称':' / '.join(sorted({r.get('商品名称','') for r in rs})),
                       '金额依据':'仅选中合并产品的源商品行BN总销额合计；不带入整单其他商品金额'})
    return result

@lru_cache(maxsize=16)
def prepared_product(stamp,product):
    base=prepared(stamp)
    if not product:return base
    selected=product_orders(base['orders'],base['items'],product)
    # 产品末次采购不能缩短完整来源的观察截止日。
    return {**prepare_orders(selected,base['meta'],base['cutoff']),'product':product}

def fit(values,horizon):
    """Bounded rolling origins, identical tests for each model; no current partial week."""
    if len(values)<12:return {'预测值':None,'状态':'不足12个完整周','回测周数':0}
    methods={'最近周延续':lambda xs:xs[-1],'近4周均值':lambda xs:sum(xs[-4:])/4,'近8周均值':lambda xs:sum(xs[-8:])/8}
    origins=list(range(8,len(values)-horizon+1))[-12:]
    if len(origins)<6:return {'预测值':None,'状态':'不足6个可回测周','回测周数':len(origins)}
    candidates=[]
    for name,predict in methods.items():
        pairs=[(predict(values[:i]),values[i+horizon-1]) for i in origins]
        error=sum(abs(p-a) for p,a in pairs)/len(pairs);den=sum(abs(a) for p,a in pairs)
        candidates.append({'方法':name,'回测MAE':error,'回测WAPE':error*len(pairs)/den if den else None,
                           '回测周数':len(pairs),'预测值':predict(values)})
    best=min(candidates,key=lambda r:r['回测MAE'])
    return {**best,'状态':'周下单金额参考；未控制节假日和交付周期','候选方法':candidates}

def analyze_prepared(state,scope,customer=''):
    if scope!=engine.ALL and scope not in state['scopes']:raise ValueError('合并客户范围不存在')
    cutoff=state['cutoff'];current=monday(cutoff);start=monday(state['first'])
    if start<state['first']:start+=timedelta(days=7)
    scope_events=[e for e in state['events'] if scope==engine.ALL or e['scope']==scope]
    people=defaultdict(list)
    for e in scope_events:people[e['key']].append(e)
    if customer and customer not in people:raise ValueError('所选客户不在当前合并客户范围内')
    summaries=[]
    for key,events in people.items():
        recent=[e for e in events if current-timedelta(days=28)<=e['date']<current]
        previous=[e for e in events if current-timedelta(days=56)<=e['date']<current-timedelta(days=28)]
        now=sum((e['amount'] for e in recent),Decimal(0));old=sum((e['amount'] for e in previous),Decimal(0))
        summaries.append({'客户键':key,'客户编号':events[0]['cid'],'客户网名':' / '.join(sorted({e['nick'] for e in events if e['nick']})) or '未提供',
                          '分组依据':events[0]['basis'],'近4完整周下单金额':float(now),'前4完整周下单金额':float(old),
                          '近4周金额变化率':float(now/old-1) if old>0 else None,'近4周有订单号单数':len({e['order'] for e in recent if e['order']}),
                          '近4周活跃周数':len({e['week'] for e in recent}),
                          '最近下单日':max(e['date'] for e in events).isoformat()})
    summaries.sort(key=lambda r:-r['近4完整周下单金额'])
    events=people.get(customer,[]) if customer else scope_events
    by_week=defaultdict(list)
    for e in events:by_week[e['week']].append(e)
    weekly=[];d=start
    while d<=current:
        es=by_week[d];end=d+timedelta(days=6);complete=end<=cutoff
        weekly.append({'范围':scope,'客户键':customer or '全部客户','周开始日期':d.isoformat(),'周结束日期':end.isoformat(),
                       '周区间':week_label(d),'周状态':'完整周' if complete else f'本周截至{cutoff.month}月{cutoff.day}日',
                       '下单金额':float(sum((e['amount'] for e in es),Decimal(0))),
                       '有订单号单数':len({e['order'] for e in es if e['order']}),
                       '活跃客户分组数':len({e['key'] for e in es if e['key']!='未识别客户'}),
                       '缺订单号计算记录数':sum(not e['order'] for e in es),
                       '未知客户金额':float(sum((e['amount'] for e in es if e['key']=='未识别客户'),Decimal(0)))})
        d+=timedelta(days=7)
    complete=[r for r in weekly if r['周状态']=='完整周'];values=[r['下单金额'] for r in complete]
    recent=values[-4:];previous=values[-8:-4];active=sum(v>0 for v in values[-12:])
    if customer:
        multi=customer_forecast.weekly(state['orders'],scope,cutoff,customer)
    else:
        import forecast_link
        multi=forecast_link.weekly(state['orders'],scope,cutoff)
        if scope==engine.ALL:
            portfolio=forecast_link.portfolio(state['orders'],cutoff)
            decomposition=portfolio.get('重点客户分解')
            if decomposition:
                multi={**multi,'周预测':decomposition['汇总周预测'],'重点客户分解':decomposition,
                       '聚合层直接周预测':multi['周预测'],'说明':multi['说明']+' 当前整体周额采用重点客户分项汇总，聚合层8法保留作对照，未被当作当前分项汇总误差。'}
    if state.get('product'):multi=deepcopy(multi)
    forecasts=[{**r,'范围':scope,'客户键':customer or '全部客户','周区间':week_label(date.fromisoformat(r['周开始日期']))} for r in multi['周预测']]
    latest=weekly[-1] if weekly else {}
    a=sum(recent);b=sum(previous)
    summary={'范围':scope,'客户键':customer or '全部客户','观察截至日期':cutoff.isoformat(),
             '完整周数':len(complete),'近4完整周周均下单金额':a/4 if len(recent)==4 else None,
             '前4完整周周均下单金额':b/4 if len(previous)==4 else None,
             '近4周金额变化率':a/b-1 if len(previous)==4 and b>0 else None,
             '近4完整周有订单号单数':sum(r['有订单号单数'] for r in complete[-4:]),
             '当前周已发生下单金额':latest.get('下单金额') if latest.get('周状态')!='完整周' else None,
             '未来4周下单金额参考':sum(r['预测值'] for r in forecasts) if all(r['预测值'] is not None for r in forecasts) else None,
             '客户分组数':len(people),'客户编号分组数':sum(r['分组依据']=='客户编号' for r in summaries),
             '网名分组数':sum(r['分组依据']=='客户网名分组' for r in summaries),
             '数据源未来交易日期记录数':state['future'],'数据源交易日期回退记录数':state['fallback']}
    product=state.get('product','')
    if product:
        for collection in (weekly,forecasts,summaries,multi.get('客户习惯',[]),multi.get('方法对照',[])):
            for r in collection:r['合并产品名称']=product
        summary['合并产品名称']=product
    return {'范围':scope,'客户键':customer,'合并产品名称':product,'汇总':summary,'周度':weekly,'客户摘要':summaries,'周预测':forecasts,
            '多逻辑预测':multi,
            '说明':('合并产品筛选直接读取源表FV引用商品库货品条码-合并产品名称分类，只汇总该产品源行BN总销额后重新建模，不将整单其他产品金额带入；观察截止仍用完整来源，不按产品末次下单缩短。' if product else '')+multi['说明']}

@lru_cache(maxsize=32)
def analyze_cached(stamp,scope,customer,product):
    return analyze_prepared(prepared_product(stamp,product),scope,customer)

def analyze(scope,customer='',product=''):
    return analyze_cached((engine.LOCAL/'current.json').stat().st_mtime_ns,scope,customer,product)

def add_snapshot(snapshot,orders,meta):
    result=analyze_prepared(prepare_orders(orders,meta),engine.ALL)
    snapshot['queries']['customer_weekly_reference']={'rows':result['周度'],'source':{
        'provider':'本地最新版订单周聚合','files':[meta['name']],'executedAt':meta.get('readAt',engine.now()),
        'evidenceFlow':[{'title':'输入范围','detail':json.dumps(meta,ensure_ascii=False)},
                        {'title':'客户周聚合','detail':'customer_weekly.py：读取验收订单，正总销额按交易日期和周一归周；动态接口/api/customer-weekly按当前合并客户与客户键过滤。'+result['说明']}],
        'metricDefinitions':[{'label':'客户周下单与辅助预测','definition':result['说明'],
                              'componentIds':['customer-weekly-summary','customer-weekly-trend','customer-weekly-forecast','customer-weekly-customers','customer-weekly-detail','customer-weekly-models','customer-purchase-habits']}]}}

