"""月中滚动估算：已实现发货销售 + 余期预测，周下单仅作为可回测的节奏特征。"""
import calendar
from collections import defaultdict
from datetime import date,timedelta
from decimal import Decimal
import customer_forecast

METHODS=('近2完整周发货日均','近4完整周发货日均','近4完整周按星期发货','周下单趋势校正')

def end_of_month(d):return d.replace(day=calendar.monthrange(d.year,d.month)[1])
def total(rows):return float(sum((Decimal(str(r['总销额'])) for r in rows),Decimal(0)))

def candidates(rows,origin):
    full_end=origin-timedelta(days=(origin.weekday()+1)%7)
    first=full_end-timedelta(days=27);middle=full_end-timedelta(days=13)
    observed=[r for r in rows if date.fromisoformat(r['日期'])<=origin]
    shipping=defaultdict(float);ordering=defaultdict(float)
    for r in observed:
        d=date.fromisoformat(r['日期'])
        if first<=d<=full_end:shipping[d]+=r['总销额']
        trade=date.fromisoformat(r.get('交易日期') or r['日期'])
        if first<=trade<=full_end and r['总销额']>0:ordering[trade]+=r['总销额']
    ship2=sum(v for d,v in shipping.items() if d>=middle)/14;ship4=sum(shipping.values())/28
    recent=sum(v for d,v in ordering.items() if d>=middle);prior=sum(v for d,v in ordering.items() if d<middle)
    change=recent/prior if prior>0 else None
    factor=max(.5,min(1.5,change)) if change is not None else 1.
    weekdays={i:sum(v for d,v in shipping.items() if d.weekday()==i)/4 for i in range(7)}
    remaining=[];d=origin+timedelta(days=1)
    while d<=end_of_month(origin):remaining.append(d);d+=timedelta(days=1)
    amounts=[ship2*len(remaining),ship4*len(remaining),sum(weekdays[d.weekday()] for d in remaining),sum(weekdays[d.weekday()]*factor for d in remaining)]
    behavior,ps=customer_forecast.predict(rows,origin,len(remaining),shipping=True)
    all_methods=list(METHODS)+list(customer_forecast.BEHAVIOR)+['星期发货与客户周期等权组合']
    extra=[sum(behavior[name].values()) for name in customer_forecast.BEHAVIOR]
    amounts+=extra+[(amounts[2]+extra[1])/2]
    return [{'方法':method,'剩余期间销售估算':amount,'预测天数':len(remaining),
             '近2完整周下单金额':recent,'前2完整周下单金额':prior,'下单趋势倍数':change,'下单趋势校正因子':factor,
             '完整周截止日期':full_end.isoformat()} for method,amount in zip(all_methods,amounts)]

def analyze(orders,scope,origin):
    rows=[r for r in orders if scope=='全部渠道' or r['渠道']==scope]
    if not rows:
        return {'已采用':False,'状态':'当前合并客户没有订单记录，不以零额代替缺失销售','本月实际销售':None,'候选方法':[]}
    # Backtest each method on the same completed months, at the same within-month day.
    folds=[]
    for month in range(1,origin.month):
        d=date(origin.year,month,min(origin.day,calendar.monthrange(origin.year,month)[1]))
        if (d-date(origin.year,1,1)).days<56:continue
        month_end=end_of_month(d)
        actual=total([r for r in rows if d<date.fromisoformat(r['日期'])<=month_end])
        full=total([r for r in rows if r['日期'].startswith(d.strftime('%Y-%m'))])
        folds.append({'截止日期':d.isoformat(),'实际余期销售':actual,'实际整月销售':full,'候选':candidates(rows,d)})
    folds=folds[-6:]
    current=candidates(rows,origin);month_start=origin.replace(day=1)
    actual=total([r for r in rows if month_start<=date.fromisoformat(r['日期'])<=origin])
    for i,model in enumerate(current):
        errors=[abs(f['候选'][i]['剩余期间销售估算']-f['实际余期销售']) for f in folds]
        den=sum(abs(f['实际整月销售']) for f in folds);remaining_den=sum(abs(f['实际余期销售']) for f in folds)
        model.update({'回测月数':len(folds),'回测MAE':sum(errors)/len(errors) if errors else None,
                      '整月回测WAPE':sum(errors)/den if den else None,'余期回测WAPE':sum(errors)/remaining_den if remaining_den else None,
                      '整月销售估算':actual+model['剩余期间销售估算']})
    if len(folds)<3:
        return {'状态':'不足3个同进度回测月份，保留已发生额，不输出周度月末预测','本月实际销售':actual,'候选方法':current,'已采用':False}
    best=min(current,key=lambda r:r['回测MAE'])
    best={**best,'已采用':True,'状态':'已发生销售加余期多模型估算；回测用于选模，非独立验证',
          '本月实际销售':actual,'数据截至日期':origin.isoformat(),'预计区间开始日期':(origin+timedelta(days=1)).isoformat(),
          '预计区间结束日期':end_of_month(origin).isoformat(),'候选方法':current,'回测明细':folds,
          '参考下沿':actual+best['剩余期间销售估算']-best['回测MAE'],
          '参考上沿':actual+best['剩余期间销售估算']+best['回测MAE'],
          '说明':'整月估算＝本月已发生发货总销额＋数据截止日之后至月底的预计销售。9种候选包括近2/4完整周发货日均、近4周按星期分配、周下单趋势校正、客户下单星期、补货间隔、TSB概率与金额、近期采购变化和等权组合。客户模型的正采购金额按典型交易至发货延迟转换，再叠加历史56天负退单日均额；已发货后才可见的订单不作为回测当时待发订单使用。趋势校正为后2完整周正下单额/前2周，限于0.5—1.5倍；下单使用交易日期且仅限当时已发货记录，未来日期不计入。所有方法在过去相同月内日的最近6个月回测，选余期MAE最低的方法；整月WAPE与余期WAPE分开。实际本月数据仅作为已实现额和近期节奏，不当作完整月份训练；未知的后续实际费用尚未提供。该表未覆盖未发货订单，不等于完整订单池预测。参考范围为余期误差参考，不是置信区间，不保证覆盖。'}
    return best
