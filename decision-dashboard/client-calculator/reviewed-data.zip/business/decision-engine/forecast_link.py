"""共享周预测日序列，联到月末发货预测；保留独立月度模型及可复算桥接。"""
import hashlib, json, statistics
from collections import defaultdict
from datetime import date,timedelta
from decimal import Decimal
import customer_forecast as cf
import month_nowcast
from threading import RLock
from pathlib import Path
from uuid import uuid4

WEEK_WEIGHT=2/3 # 用户更偏向周度逻辑；明确为可评估偏好，不声称是统计最优权重。
CACHE={}
WEEK_CACHE={}
PORTFOLIO_CACHE={}
PORTFOLIO_LOCK=RLock()
DISK=Path(__file__).resolve().parent/'private/forecast-link-cache'
VERSION=hashlib.sha256(b''.join((Path(__file__).parent/f).read_bytes() for f in ('forecast_link.py','customer_forecast.py','month_nowcast.py'))).hexdigest()
def disk_path(kind,key):return DISK/(kind+'-'+hashlib.sha256(json.dumps([VERSION,key],ensure_ascii=False).encode()).hexdigest()+'.json')
def disk_read(kind,key):
    p=disk_path(kind,key)
    if not p.exists():return None
    try:return json.loads(p.read_text(encoding='utf-8'))
    except (OSError,ValueError):return None
def disk_write(kind,key,value):
    DISK.mkdir(exist_ok=True);target=disk_path(kind,key);tmp=target.with_suffix('.'+uuid4().hex+'.tmp')
    tmp.write_text(json.dumps(value,ensure_ascii=False,allow_nan=False),encoding='utf-8');tmp.replace(target)
def signature(rows):
    return hashlib.sha256(json.dumps([(r['日期'],r.get('交易日期'),r['总销额'],r.get('客户编号'),r.get('客户网名'),r['渠道']) for r in rows],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
def weekly(rows,scope,origin):
    rows=[r for r in rows if scope=='全部渠道' or r['渠道']==scope]
    key=(signature(rows),scope,origin.isoformat())
    if key not in WEEK_CACHE:
        if len(WEEK_CACHE)>48:WEEK_CACHE.clear()
        cached=disk_read('week',key)
        WEEK_CACHE[key]=cached if cached is not None else cf.weekly(rows,scope,origin)
        if cached is None:disk_write('week',key,WEEK_CACHE[key])
    return WEEK_CACHE[key]

def bridge(rows,scope,origin):
    """采购日预测按近期已知的金额加权发货时滞分布映射，不假设所有周额均当月发货。"""
    w=weekly(rows,scope,origin);daily={date.fromisoformat(r['日期']):r['预计正向下单额'] for r in w['每日预测']}
    if len(w['周预测'])!=4 or any(r['预测值'] is None for r in w['周预测']):return {'可用':False,'周预测':w['周预测'],'每日预测':[]}
    if max(daily,default=origin)<month_nowcast.end_of_month(origin):return {'可用':False,'周预测':w['周预测'],'每日预测':[],'状态':'四周预测未覆盖月底，保留原月度逻辑'}
    known=cf.visible(rows,origin);lags=defaultdict(float)
    for r in known:
        if r['总销额']<=0 or r['日期']<(origin-timedelta(days=83)).isoformat():continue
        lag=(date.fromisoformat(r['日期'])-date.fromisoformat(r.get('交易日期') or r['日期'])).days
        if 0<=lag<=56:lags[lag]+=r['总销额']
    if not lags:return {'可用':False,'周预测':w['周预测'],'每日预测':[]}
    den=sum(lags.values());weights={k:v/den for k,v in lags.items()}
    shipping=defaultdict(float)
    for d,v in daily.items():
        for lag,p in weights.items():shipping[d+timedelta(days=lag)]+=v*p
    refund=sum(r['总销额'] for r in known if r['总销额']<0 and r['日期']>=(origin-timedelta(days=55)).isoformat())/56
    last=month_nowcast.end_of_month(origin);first=origin+timedelta(days=1)
    for d in cf.dates(first,max(last,max(shipping,default=last))):shipping[d]+=refund
    month_order=sum(v for d,v in daily.items() if d<=last)
    month_positive=sum(v for d,v in shipping.items() if first<=d<=last)-refund*(last-origin).days
    amount=sum(v for d,v in shipping.items() if first<=d<=last)
    return {'可用':True,'周预测':w['周预测'],'每日预测':[{'日期':d.isoformat(),'预计正向下单额':daily.get(d,0.),'周映射净销售':shipping.get(d,0.)} for d in sorted(set(daily)|set(shipping))],
            '月内余期下单额':month_order,'月内余期正向发货额':month_positive,'余期退单调整':refund*(last-origin).days,'周映射余期销售':amount,
            '发货时滞影响':month_positive-month_order,'金额加权平均发货天数':sum(k*v for k,v in weights.items()),
            '发货时滞分布':[{'发货延迟天数':k,'金额权重':v} for k,v in sorted(weights.items())]}

def analyze(orders,scope,origin):
    rows=[r for r in orders if scope=='全部渠道' or r['渠道']==scope]
    key=(signature(rows),scope,origin.isoformat())
    if key in CACHE:return CACHE[key]
    cached=disk_read('month',key)
    if cached is not None:CACHE[key]=cached;return cached
    old=month_nowcast.analyze(rows,scope,origin)
    if not old.get('已采用'):return old
    current=bridge(rows,scope,origin)
    if not current['可用']:return {**old,'周月关联状态':'周预测历史不足，保留月度原逻辑'}
    tests=[]
    for fold in old['回测明细']:
        cutoff=date.fromisoformat(fold['截止日期'])
        # Monthly choice at each historical cutoff uses only earlier monthly folds.
        earlier=[f for f in old['回测明细'] if f['截止日期']<fold['截止日期']]
        if len(earlier)<3:continue
        past=bridge(rows,scope,cutoff)
        if not past['可用']:continue
        idx=min(range(len(old['候选方法'])),key=lambda i:statistics.mean(abs(f['候选'][i]['剩余期间销售估算']-f['实际余期销售']) for f in earlier))
        monthly=fold['候选'][idx]['剩余期间销售估算'];weekly_amount=past['周映射余期销售']
        tests.append({'截止日期':fold['截止日期'],'实际余期销售':fold['实际余期销售'],'实际整月销售':fold['实际整月销售'],'周映射余期销售':weekly_amount,'月度原逻辑余期销售':monthly,'周月结合余期销售':WEEK_WEIGHT*weekly_amount+(1-WEEK_WEIGHT)*monthly,'月度方法':fold['候选'][idx]['方法']})
    # At least three chronological held-out months for the combined recipe.
    if len(tests)<3:return {**old,'周月关联状态':'周月联合回测不足3个月，保留原月度预测','周月衔接':current}
    method='周月结合（周2/3＋月1/3）';month_amount=old['剩余期间销售估算'];week_amount=current['周映射余期销售']
    remaining=WEEK_WEIGHT*week_amount+(1-WEEK_WEIGHT)*month_amount
    errors=[abs(r['周月结合余期销售']-r['实际余期销售']) for r in tests];mae=statistics.mean(errors)
    actual=old['本月实际销售'];den=sum(abs(r['实际整月销售']) for r in tests);rden=sum(abs(r['实际余期销售']) for r in tests)
    comparison=[]
    for label,field,amount in [('周预测映射','周映射余期销售',week_amount),('月度原逻辑','月度原逻辑余期销售',month_amount),(method,'周月结合余期销售',remaining)]:
        errs=[abs(r[field]-r['实际余期销售']) for r in tests]
        comparison.append({'方法':label,'剩余期间销售估算':amount,'整月销售估算':actual+amount,'回测MAE':statistics.mean(errs),'余期回测WAPE':sum(errs)/rden if rden else None,'回测月数':len(tests),'当前采用':'已采用' if label==method else '对照'})
    last=month_nowcast.end_of_month(origin);days=cf.dates(origin+timedelta(days=1),last)
    # Monthly signal calibrates the same remaining daily sales series, preserving exact additivity.
    by_day={r['日期']:r for r in current['每日预测']};positive=sum(max(0,by_day.get(d.isoformat(),{}).get('周映射净销售',0)) for d in days)
    calibration=remaining-week_amount;daily=[]
    for d in days:
        r=by_day.get(d.isoformat(),{});base=r.get('周映射净销售',0.)
        allocation=max(0,base)/positive if positive>0 else 1/len(days)
        daily.append({'日期':d.isoformat(),'周开始日期':(d-timedelta(days=d.weekday())).isoformat(),'周预计正向下单额':r.get('预计正向下单额',0.),'周映射净销售':base,'月度逻辑校准':calibration*allocation,'联动预计净销售':base+calibration*allocation})
    weeks=[]
    for w in current['周预测']:
        start=date.fromisoformat(w['周开始日期']);end=date.fromisoformat(w['周结束日期'])
        subset=[r for r in daily if w['周开始日期']<=r['日期']<=w['周结束日期']]
        known=cf.visible(rows,origin)
        observed_ship=sum(r['总销额'] for r in known if start.isoformat()<=r['日期']<=min(end,origin).isoformat()) if start<=origin else 0.
        remaining_orders=[r for r in current['每日预测'] if w['周开始日期']<=r['日期']<=w['周结束日期']]
        weeks.append({'周开始日期':w['周开始日期'],'周结束日期':w['周结束日期'],'预计整周下单额':w['预测值'],'周内已发生下单额':w['本周已发生额'],
            '本月余期下单额':sum(r['预计正向下单额'] for r in remaining_orders if r['日期']<=last.isoformat()),
            '跨到下月的下单预测额':sum(r['预计正向下单额'] for r in remaining_orders if r['日期']>last.isoformat()),
            '本月余期周映射净销售':sum(r['周映射净销售'] for r in subset),'本月月度校准金额':sum(r['月度逻辑校准'] for r in subset),
            '本月余期联动销售':sum(r['联动预计净销售'] for r in subset),'周内已发生发货销售':observed_ship,'周预测方法':w['方法']})
    result={**old,'方法':method,'剩余期间销售估算':remaining,'整月销售估算':actual+remaining,'回测MAE':mae,'回测月数':len(tests),'整月回测WAPE':sum(errors)/den if den else None,'余期回测WAPE':sum(errors)/rden if rden else None,
        '参考下沿':actual+remaining-mae,'参考上沿':actual+remaining+mae,'月度原逻辑':{k:v for k,v in old.items() if k not in ('回测明细','说明')},
        '周月衔接':{**current,'周权重':WEEK_WEIGHT,'月权重':1-WEEK_WEIGHT,'月度原余期销售':month_amount,'月度校准金额':calibration,'周月对照':comparison,'周月回测明细':tests,'月内每日预测':daily,'周到月核对':weeks},
        '说明':old['说明']+' 本次采用共享周日序列与原月度逻辑组合：周2/3、月1/3，为使用偏好固定权重，并非最优权重。周额先扣已发生、切到月底，再按84天已知正金额加权发货时滞分布（0—56天）映射销售，并加56天负退单日均；尚未发货的真实在途订单池缺失。日历余期映射额与月度原余期预测按权重结合，校准分配到同一余期日序列，因此周内月度贡献之和等于月余期预测。组合回测至少3个历史月，月度方法只用该折之前至少3折选择；周模型仅用该时点已知订单和已结束测试周。组合可能不优于单一路径，对照误差可见；不宣称联合权重最优或实际库存已知。'}
    if len(CACHE)>16:CACHE.clear()
    CACHE[key]=result
    disk_write('month',key,result)
    return result

def portfolio(orders,origin):
    key=(signature(orders),origin.isoformat())
    with PORTFOLIO_LOCK:
        if key in PORTFOLIO_CACHE:return PORTFOLIO_CACHE[key]
        cached=disk_read('portfolio',key)
        result=cached if cached is not None else _portfolio(orders,origin)
        if len(PORTFOLIO_CACHE)>2:PORTFOLIO_CACHE.clear()
        PORTFOLIO_CACHE[key]=result
        if cached is None:disk_write('portfolio',key,result)
        return result

def _portfolio(orders,origin):
    direct=analyze(orders,'全部渠道',origin)
    if not direct.get('周月衔接',{}).get('周到月核对'):return direct
    year=origin.year;month=origin.month-3
    while month<=0:month+=12;year-=1
    start=date(year,month,1);end=origin.replace(day=1)-timedelta(days=1)
    sales=defaultdict(float)
    for r in cf.visible(orders,origin):
        if start.isoformat()<=r['日期']<=end.isoformat() and r['总销额']>0:sales[r['渠道']]+=r['总销额']
    denominator=sum(sales.values());major=[];cumulative=0.
    for name,amount in sorted(sales.items(),key=lambda p:-p[1]):
        if len(major)>=10 or (major and cumulative>=denominator*.8):break
        major.append(name);cumulative+=amount
    parts=[(name,analyze(orders,name,origin)) for name in major]
    other=[r for r in orders if r['渠道'] not in major]
    if other:parts.append(('其他客户合计',analyze(other,'全部渠道',origin)))
    if any(not r.get('已采用') for _,r in parts):return {**direct,'重点客户分解状态':'分项历史不足，暂保留整体模型；未以零填补未知'}
    actual=sum(r['本月实际销售'] for _,r in parts);remaining=sum(r['剩余期间销售估算'] for _,r in parts)
    assert abs(actual-direct['本月实际销售'])<1e-6
    contribution=[];daily=defaultdict(lambda:defaultdict(float));combined_weeks=[]
    all_weeks=[r.get('周月衔接',{}).get('周预测') for _,r in parts]
    if not all(all_weeks):return {**direct,'重点客户分解状态':'部分客户无足够周预测历史，保留整体模型'}
    for name,r in parts:
        member_rows=[o for o in orders if (name=='其他客户合计' and o['渠道'] not in major) or o['渠道']==name]
        full_months=[(end.replace(day=1)-timedelta(days=1)).replace(day=1)]
        recent_keys=[];cursor=end
        for _ in range(3):
            recent_keys.append(cursor.strftime('%Y-%m'));cursor=cursor.replace(day=1)-timedelta(days=1)
        history={k:float(sum((Decimal(str(o['总销额'])) for o in member_rows if o['日期'].startswith(k)),Decimal(0))) for k in recent_keys}
        contribution.append({'合并客户名称':name,'近3完整月正向发货额':sales.get(name,denominator-cumulative if name=='其他客户合计' else 0.),'历史发货占比':sales.get(name,denominator-cumulative if name=='其他客户合计' else 0.)/denominator if denominator else None,
             '最近完整月份':recent_keys[0],'最近完整月发货额':history[recent_keys[0]],'前一完整月份':recent_keys[1],'前一完整月发货额':history[recent_keys[1]],'前二完整月份':recent_keys[2],'前二完整月发货额':history[recent_keys[2]],
             '本月实际发货额':r['本月实际销售'],'周映射余期销售':r['周月衔接']['周映射余期销售'],'月度原余期销售':r['周月衔接']['月度原余期销售'],'周月校准金额':r['周月衔接']['月度校准金额'],
             '余期销售预测':r['剩余期间销售估算'],'整月销售预测':r['整月销售估算'],'采用逻辑':r['方法'],'联合回测MAE':r['回测MAE'],'联合回测月数':r['回测月数']})
        for d in r['周月衔接']['月内每日预测']:
            for field in ('周预计正向下单额','周映射净销售','月度逻辑校准','联动预计净销售'):daily[d['日期']][field]+=d[field]
    monthly_days=[{'日期':d,'周开始日期':(date.fromisoformat(d)-timedelta(days=date.fromisoformat(d).weekday())).isoformat(),**vs} for d,vs in sorted(daily.items())]
    for h in range(4):
        ws=[p[h] for p in all_weeks];one=ws[0]
        value=sum(w['预测值'] for w in ws);error=sum(w['回测MAE'] for w in ws)
        combined_weeks.append({'预测步数':h+1,'周开始日期':one['周开始日期'],'周结束日期':one['周结束日期'],'预测值':value,'方法':'重点客户分别预测后汇总','本周已发生额':sum(w['本周已发生额'] for w in ws),'剩余期间预测值':sum(w['剩余期间预测值'] for w in ws),
            '回测MAE':error,'回测WAPE':None,'回测周数':min(w['回测周数'] for w in ws),'参考下沿':max(0,value-error),'参考上沿':value+error,'状态':'分项预测汇总；误差带为分项MAE之和，非整体回测误差'})
    bridge_weeks=[]
    for h in range(4):
        ws=[r['周月衔接']['周到月核对'][h] for _,r in parts];one=ws[0]
        fields=('预计整周下单额','周内已发生下单额','本月余期下单额','跨到下月的下单预测额','本月余期周映射净销售','本月月度校准金额','本月余期联动销售','周内已发生发货销售')
        bridge_weeks.append({'周开始日期':one['周开始日期'],'周结束日期':one['周结束日期'],**{f:sum(w[f] for w in ws) for f in fields},'周预测方法':'重点客户分别预测后汇总'})
    common_dates=set.intersection(*[{x['截止日期'] for x in r['周月衔接']['周月回测明细']} for _,r in parts])
    # Partition fixed for this forecast. The held-out error is conditional on today's grouping, not an independent portfolio validation.
    tests=[]
    for cutoff in sorted(common_dates):
        ts=[next(t for t in r['周月衔接']['周月回测明细'] if t['截止日期']==cutoff) for _,r in parts]
        tests.append({'截止日期':cutoff,**{f:sum(t[f] for t in ts) for f in ('实际余期销售','实际整月销售','周映射余期销售','月度原逻辑余期销售','周月结合余期销售')}})
    errs=[abs(t['周月结合余期销售']-t['实际余期销售']) for t in tests];mae=statistics.mean(errs) if errs else None
    den=sum(abs(t['实际整月销售']) for t in tests);rden=sum(abs(t['实际余期销售']) for t in tests)
    details={'筛选开始日期':start.isoformat(),'筛选结束日期':end.isoformat(),'累计贡献门槛':.8,'重点客户上限':10,'重点客户数':len(major),'重点客户历史占比':cumulative/denominator if denominator else None,
             '客户贡献':contribution,'汇总周预测':combined_weeks,'回测解释':'各分项按时间隔离预测后，汇总同月误差；分组以当前近3完整月选定，因此误差为当前分组条件下历史检验，不代表独立组合选样回测。'}
    link={**direct['周月衔接'],'月内每日预测':monthly_days,'周到月核对':bridge_weeks,'周预测':combined_weeks,'周月回测明细':tests,
          '周映射余期销售':sum(c['周映射余期销售'] for c in contribution),'月度原余期销售':sum(c['月度原余期销售'] for c in contribution),'月度校准金额':sum(c['周月校准金额'] for c in contribution),
          '周月对照':[{'方法':'重点客户周月预测汇总','剩余期间销售估算':remaining,'整月销售估算':actual+remaining,'回测MAE':mae,'余期回测WAPE':sum(errs)/rden if rden else None,'回测月数':len(tests),'当前采用':'已采用'},
                     {'方法':'整体直接周月模型','剩余期间销售估算':direct['剩余期间销售估算'],'整月销售估算':direct['整月销售估算'],'回测MAE':direct['回测MAE'],'余期回测WAPE':direct['余期回测WAPE'],'回测月数':direct['回测月数'],'当前采用':'对照'}]}
    result={**direct,'方法':'重点客户月度发货＋周下单分项汇总','本月实际销售':actual,'剩余期间销售估算':remaining,'整月销售估算':actual+remaining,
            '回测MAE':mae,'回测月数':len(tests),'整月回测WAPE':sum(errs)/den if den else None,'余期回测WAPE':sum(errs)/rden if rden else None,
            '参考下沿':actual+remaining-mae if mae is not None else None,'参考上沿':actual+remaining+mae if mae is not None else None,
            '重点客户分解':details,'周月衔接':link,'说明':direct['说明']+' 整体先按近3完整月正向发货贡献降序选择累计80%且最多10个合并客户，每个分别运行周月模型，其余客户作为独立剩余组，最后逐项汇总。分项金额不与整体直接模型重复相加；整体直接模型作为对照。组合历史误差受当前分组选样影响，尚非独立组合验证。'}
    return result
