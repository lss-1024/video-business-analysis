"""Read-only view requests. Each filtered calculation runs in its own process.

This keeps the existing model caches isolated by population, and prevents two
visitors' unit/date selections from changing each other's calculations.
"""
import calendar, hashlib, json, subprocess, sys, threading
from datetime import date
from functools import lru_cache
from pathlib import Path
import engine
from contextlib import nullcontext

UNITS=['大客户业务单元','大单品业务单元','线下闭环']
GATE=threading.BoundedSemaphore(2)

@lru_cache(maxsize=1)
def catalog(stamp):
    current=engine.load_current()
    orders,_,_,_=engine.validate(current['records'])
    import financial_report
    finance,_=financial_report.load()
    return options_from_rows(orders,finance)

def options_from_rows(orders,finance):
    days=sorted({r.get('发货日期') for r in orders if r.get('发货日期')})
    choices={u:sorted({r['渠道'] for r in orders if not u or r.get('业务单元')==u}
                       |{r['合并客户名称'] for r in finance if not u or r.get('业务单元')==u}) for u in ['',*UNITS]}
    return {'days':days,'units':UNITS,'customers':choices,'start':days[0],'end':days[-1]}

def options():return catalog((engine.LOCAL/'current.json').stat().st_mtime_ns)

def add_filter_definitions(snapshot):
    o=snapshot['businessContext']['viewOptions']
    snapshot['queries']['view_filter_options']={'rows':[{'业务单元':u,'发货日期':d} for u in ['全部单元',*o['units']] for d in o['days']],
                                               'source':snapshot['queries']['finance']['source']}
    snapshot['filters']=[f for f in snapshot.get('filters',[]) if f['id'] not in ['businessUnit','shippingRange']]+[
        {'id':'businessUnit','label':'7月对应业务单元','field':'业务单元','defaultValue':'全部单元','queryIds':['view_filter_options']},
        {'id':'shippingRange','label':'发货日期','field':'发货日期','mode':'through','defaultValue':o['start']+'..'+o['end'],'queryIds':['view_filter_options']}]

def add_reading(snapshot,orders,items,start,end):
    """Accounting contributions to the latest two fully observed months."""
    from collections import defaultdict
    from decimal import Decimal
    months=[f'2026-{m:02}' for m in range(1,13) if start<=f'2026-{m:02}-01'
            and f'2026-{m:02}-{calendar.monthrange(2026,m)[1]}'<=end]
    rows=[]
    if len(months)>1:
        before,after=months[-2:]
        for scope in snapshot['businessContext']['scopes']:
            for kind,facts,field in [('客户',orders,'渠道'),('合并产品',items,'合并产品名称')]:
                grouped=defaultdict(lambda:defaultdict(Decimal))
                for r in facts:
                    if scope!=engine.ALL and r['渠道']!=scope:continue
                    m=r['日期'][:7]
                    if m not in [before,after] or r.get('总销额') is None:continue
                    name=r.get(field) or '合并名称未提供'
                    grouped[name][m]+=Decimal(str(r['总销额']))
                out=[{'范围':scope,'维度':kind,'名称':name,'前月':before,'后月':after,
                      '前月销额':float(v[before]),'后月销额':float(v[after]),
                      '销额变化':float(v[after]-v[before])} for name,v in grouped.items()]
                rows.extend(sorted(out,key=lambda r:abs(r['销额变化']),reverse=True)[:3])
    snapshot['queries']['movement_drivers']={'rows':rows,'source':{
        **snapshot['queries']['finance']['source'],
        'metricDefinitions':[{'label':'完整月波动贡献','definition':'所选发货日期完全覆盖的最近两个日历月，分别按合并客户名称和合并产品名称计算后月BN总销额减前月BN总销额，按绝对变化取前三。空名称单列，未填商品金额不补零。两种维度是同一销售额的不同拆解，不相加，不代表因果。','componentIds':['operating-movement-reading']}]}}

def request(path,params):
    unit=params.get('businessUnit',[''])[0]
    if unit=='全部单元':unit=''
    if unit and unit not in UNITS:raise ValueError('业务单元选项无效')
    c=options();start=params.get('shippingStart',[c['start']])[0];end=params.get('shippingEnd',[c['end']])[0]
    date.fromisoformat(start);date.fromisoformat(end)
    if not c['start']<=start<=end<=c['end']:raise ValueError('发货日期范围超出已读取的数据覆盖期')
    scope=params.get('scope',[engine.ALL])[0]
    if scope!=engine.ALL and scope not in c['customers'][unit]:raise ValueError('所选合并客户不属于当前业务单元')
    if path in ['/api/customer-weekly','/api/expense-diagnostics','/api/collaboration-view','/api/collaboration-target']:
        params={k:v for k,v in params.items() if k not in ['shippingStart','shippingEnd']}
        start,end=c['start'],c['end']
    payload={'path':path,'params':params,'unit':unit,'start':start,'end':end,'scope':scope}
    return cached_request(json.dumps(payload,sort_keys=True,ensure_ascii=False),
                          (engine.LOCAL/'current.json').stat().st_mtime_ns,
                          (engine.ROOT/'财务底数据_2026/01_客户月财务底表.csv').stat().st_mtime_ns)

@lru_cache(maxsize=12)
def cached_request(payload,stamp,finance_stamp):
    with (nullcontext() if json.loads(payload)['path']=='/api/dashboard-view' else GATE):
        result=subprocess.run([sys.executable,'-X','utf8',str(Path(__file__))],input=payload,
                              text=True,encoding='utf-8',capture_output=True,timeout=240)
    if result.returncode:raise ValueError(result.stderr[-1500:] or '筛选计算失败')
    value=json.loads(result.stdout)
    if 'viewError' in value:raise ValueError(value['viewError'])
    return value

def run(p):
    import financial_population as fp
    import financial_report as fr
    original=engine.load_current()
    all_orders,all_items,_,_=engine.validate(original['records'])
    c=options();unit=p['unit'];start=p['start'];end=p['end'];scope=p['scope'];route=p['path']
    # Historical actuals use the exact shipping window. Forecasts and purchasing
    # rhythm retain all available history, explicitly labelled by the content UI.
    historical=route in ['/api/dashboard-view','/api/marketing-effect','/api/order-finance-reconciliation','/api/customer-detail']
    months={f'2026-{m:02}' for m in range(1,13)
            if start<=f'2026-{m:02}-01' and f'2026-{m:02}-{calendar.monthrange(2026,m)[1]}'<=end}
    fp.ACTIVE_UNIT=unit;fp.ACTIVE_MONTHS=months if historical else None
    records=[r for r in original['records'] if (not unit or r.get('业务单元')==unit)
             and (not historical or bool(r.get('发货日期')) and start<=r['发货日期']<=end)]
    # Shipment-date selection also retains linked items; canonical order/item keys
    # already share a shipping day and business unit at the source grain.
    selected={**original,'records':records,'meta':{**original['meta'],'viewObservationEnd':c['end'],'viewDisplayEnd':end}}
    engine.load_current=lambda:selected
    args=p['params'];arg=lambda k,d='':args.get(k,[d])[0]
    if route=='/api/dashboard-view':
        old=_BROWSER_SNAPSHOT
        rows=[r for r in records if r.get('记录类型')=='订单']
        if rows:
            result=engine.build_snapshot(records,{**original['meta'],'view':p},view=p)
            os,it,*_=engine.validate(records)
            if scope=='联名客户':
                import collaboration_sales
                collaboration_sales.add_snapshot(result,os,it,selected['meta'],forecasts=False)
        else:
            result={**old,'queries':{k:{**v,'rows':[]} for k,v in old['queries'].items()},
                    'businessContext':{**old['businessContext'],'audit':{'订单数':0}}}
            fr.add_snapshot(result,[],engine.ALL)
        # Dynamic evidence wrappers retain their registered query IDs. Do not
        # carry unfiltered actual rows into a filtered source inspector.
        for k,q in old['queries'].items():
            result['queries'].setdefault(k,{**q,'rows':[]})
        import marketing_effect
        result['queries']['weekly_products']={'rows':marketing_effect.catalog_from_items([r for r in all_items if not unit or r.get('业务单元')==unit]),
                                              'source':old['queries']['merged_products']['source']}
        for q in result['queries'].values():
            q['rows']=[r for r in q['rows'] if r.get('范围',scope) in [scope,engine.ALL]]
            q['source']={**q.get('source',{}),'viewSelection':{'businessUnit':unit or '全部单元','shippingStart':start,'shippingEnd':end,'scope':scope},
                'evidenceFlow':[*q.get('source',{}).get('evidenceFlow',[]),{'title':'当前查看范围','detail':f'发货日期{start}至{end}；业务单元={unit or "全部单元"}；合并客户={scope}。财务仅纳入完整覆盖的月份，不拆分月度费用。'}]}
        result['businessContext'].update(start=start,end=end,scopes=[engine.ALL,*c['customers'][unit]],
            view={'unit':unit,'start':start,'end':end,'financialMonths':sorted(months & {f'2026-{i:02}' for i in range(1,10)}),
                  'observationEnd':c['end'],'strictShipping':True},model=None)
        return result
    if route=='/api/marketing-effect':
        import marketing_effect as m
        if not records:raise ValueError('所选发货日期范围没有订单，月度费用联动暂不可计算')
        m.MONTHS=sorted(months & set(m.MONTHS))
        if not m.MONTHS:raise ValueError('当前日期范围未完整覆盖任何已结算财务月份，不能将整月费用与部分月销售计算联动')
        return m.analyze(scope,arg('subject','营销费用合计'),arg('metric','总销额'),arg('sku'),arg('product'),arg('unit'))
    if route=='/api/order-finance-reconciliation':
        import order_finance_reconciliation as m
        d=m.load();d['orders']=[r for r in d['orders'] if (not unit or r.get('26年7月对应业务单元')==unit)
            and r.get('发货日期') and r['发货日期'][:7] in months]
        d['finance']=[r for r in d['finance'] if not fp.excluded(r)]
        m.load=lambda *a:d;m.MONTHS=sorted(months & set(m.MONTHS))
        return m.analyze(scope,arg('nickname'),arg('population','full'))
    if route=='/api/customer-detail':
        from server import customer_detail
        return customer_detail(arg('customer'),scope)
    if route=='/api/customer-weekly':
        import customer_weekly as m
        return m.analyze(scope,arg('customer'),arg('product'))
    if route=='/api/expense-diagnostics':
        import expense_diagnostics as m
        return m.analyze(scope,arg('metric','总销额'),arg('sku'),arg('month'),arg('product'),arg('unit'))
    if route=='/api/collaboration-target':
        import collaboration_sales as m
        return m.with_target(arg('target'),arg('unit'))
    if route=='/api/collaboration-view':
        import collaboration_sales as m
        os,it,*_=engine.validate(records)
        return m.analyze(os,it,selected['meta'])
    raise ValueError('不支持的筛选查询')

if __name__=='__main__':
    try:print(json.dumps(run(json.load(sys.stdin)),ensure_ascii=False,allow_nan=False))
    except Exception as e:
        import traceback
        traceback.print_exc(file=sys.stderr);sys.exit(1)
