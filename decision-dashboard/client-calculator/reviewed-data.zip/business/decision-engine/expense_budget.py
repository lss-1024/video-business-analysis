"""Conditional expense budgets: chronological selection, sales drivers and explicit denominators.

Costs are accounting amounts, not causal returns. No margin-based cap is applied.
"""
import math
import statistics
from collections import defaultdict
from decimal import Decimal
from functools import lru_cache

import engine
import financial_report

CATEGORIES = (
    ('营销费用', '营销费用合计', '营销费用额合计'),
    ('履约费用', '履约费用合计', '履约费用额'),
    ('人员费用', '人员费用额', '人员费用额'),
    ('税费', '税费额（4%）', '税费额（4%）'),
)
METHODS = ('上月金额延续', '近3月金额均值', '历史金额均值',
           '上月费用率', '近3月加权费用率', '历史加权费用率',
           '相近销售规模3月费用率', '固定＋随销混合')


def total(values):
    return float(sum((Decimal(str(v)) for v in values if v is not None), Decimal(0)))


@lru_cache(maxsize=2)
def history(current_stamp, finance_stamp, scope):
    finance, _ = financial_report.load()
    orders, _, _, _ = engine.validate(engine.load_current()['records'])
    by = defaultdict(list)
    for row in finance:
        if scope == engine.ALL or row['合并客户名称'] == scope:
            by[row['月份']].append(row)
    output = []
    for index in range(1, 10):
        month = f'2026-{index:02}'
        fs = by[month]
        os = [r for r in orders if r['日期'].startswith(month)
              and (scope == engine.ALL or r['渠道'] == scope)
              and r.get('利润处理') != '不计算利润' and r['渠道'] != '联名客户']
        amounts, missing = {}, {}
        for field in ('最终收入', '最终毛利', *financial_report.FEES):
            known = [r[field] for r in fs if r[field] is not None]
            amounts[field] = total(known) if known else None
            missing[field] = sum(r[field] is None for r in fs)
        output.append({'月份': month, '订单销售': total(r['总销额'] for r in os) if os else None,
                       '财务行数': len(fs), '财务': amounts, '未填': missing})
    return output


def load_history(scope):
    return history((engine.LOCAL/'current.json').stat().st_mtime_ns,
                   (financial_report.DIR/'01_客户月财务底表.csv').stat().st_mtime_ns, scope)


def parameters(pairs, method, sales):
    """Return nonnegative intercept and slope; signed historical adjustments remain in training."""
    if len(pairs) < 3 or sales is None or sales <= 0:
        return None
    chosen = pairs
    if method.startswith('上月'):
        chosen = pairs[-1:]
    elif method.startswith('近3月'):
        chosen = pairs[-3:]
    elif method.startswith('相近'):
        chosen = sorted(pairs, key=lambda r: (abs(math.log(r['销售']/sales)), -int(r['月份'].replace('-', ''))))[:3]
    xs = [p['销售'] for p in chosen]
    ys = [p['费用'] for p in chosen]
    if '金额' in method:
        intercept, slope = max(0, statistics.mean(ys)), 0.
    elif method == '固定＋随销混合':
        # Exact constrained least squares in two dimensions: interior and both boundaries.
        xm, ym = statistics.mean(xs), statistics.mean(ys)
        xx = sum((x-xm)**2 for x in xs)
        b = sum((x-xm)*(y-ym) for x,y in zip(xs,ys))/xx if xx > 1e-12 else 0.
        a = ym-b*xm
        candidates = [(max(0, ym), 0.), (0., max(0, sum(x*y for x,y in zip(xs,ys))/sum(x*x for x in xs)))]
        if a >= 0 and b >= 0:
            candidates.append((a,b))
        intercept, slope = min(candidates, key=lambda ab: sum((ab[0]+ab[1]*x-y)**2 for x,y in zip(xs,ys)))
    else:
        intercept, slope = 0., max(0, total(ys)/total(xs))
    return {'固定基线': intercept, '随销系数': slope, '预测值': intercept+slope*sales,
            '参考月份': '、'.join(p['月份'] for p in chosen)}


def valid_pairs(rows, field):
    # Partial filled sums stay visible, but are never silently used as complete cost targets.
    return [{'月份': r['月份'], '销售': r['订单销售'], '费用': r['财务'][field]}
            for r in rows if r['订单销售'] is not None and r['订单销售'] > 0
            and r['财务'][field] is not None and r['未填'][field] == 0]


def score_methods(rows, field, horizon=1):
    tests = []
    for i in range(4, len(rows)-horizon+1):
        past = valid_pairs(rows[:i], field)
        target = valid_pairs(rows[i+horizon-1:i+horizon], field)
        if len(past) < 4 or not target:
            continue
        target = target[0]
        tests.append((past, target))
    result = []
    for method in METHODS:
        folds = []
        for past, target in tests:
            pred = parameters(past, method, target['销售'])['预测值']
            folds.append({'月份': target['月份'], '训练截止月份': past[-1]['月份'],
                          '条件销售额': target['销售'], '实际费用': target['费用'],
                          '预计费用': pred, '绝对误差': abs(pred-target['费用'])})
        if folds:
            den = total(r['实际费用'] if r['实际费用'] >= 0 else -r['实际费用'] for r in folds)
            err = total(r['绝对误差'] for r in folds)
            result.append({'方法': method, '回测MAE': err/len(folds), '回测WAPE': err/den if den else None,
                           '回测月数': len(folds), '回测明细': folds})
    return result


def benchmark(rows, field, sales):
    pairs = valid_pairs(rows, field)
    def rate(ps):
        return total(r['费用'] for r in ps)/total(r['销售'] for r in ps) if ps else None
    last = pairs[-1:] if pairs else []
    recent = pairs[-3:]
    peers = sorted(pairs, key=lambda p: abs(math.log(p['销售']/sales)))[:3] if sales and sales > 0 else []
    return {'最近完整月份': last[0]['月份'] if last else '', '上月费用率': rate(last),
            '近3完整月费用率': rate(recent), '历史订单费用率': rate(pairs),
            '相近销售规模费用率': rate(peers), '相近销售月份': '、'.join(r['月份'] for r in peers)}


def category_fit(rows, category, label, field, sales, low, high, horizon, joint_tests):
    pairs = valid_pairs(rows, field)
    scores = score_methods(rows, field, horizon)
    out = {'费用大类': category, '费用类别': label, **benchmark(rows, field, sales),
           '预测值': None, '方法': None, '回测MAE': None, '回测WAPE': None, '回测月数': 0,
           '参考下沿': None, '参考上沿': None, '候选方法': [], '状态': '完整可回测月份不足3个，未补零',
           '不完整月份': '、'.join(r['月份'] for r in rows if r['未填'][field] or r['财务'][field] is None)}
    if not scores or scores[0]['回测月数'] < 3 or sales is None or sales <= 0:
        return out
    best = min(scores, key=lambda r: r['回测MAE'])
    fit = parameters(pairs, best['方法'], sales)
    lower = parameters(pairs, best['方法'], low)['预测值'] if low and low > 0 else fit['固定基线']
    upper = parameters(pairs, best['方法'], high)['预测值'] if high and high > 0 else fit['预测值']
    # Each candidate has its own source-derived coefficients, not a forced margin/rate target.
    candidates = [{**{k:v for k,v in s.items() if k != '回测明细'},
                   **parameters(pairs, s['方法'], sales), '当前采用': s['方法'] == best['方法'],
                   '费用大类': category, '费用类别': label} for s in scores]
    joint = []
    for test in joint_tests:
        month = test['截止日期'][:7]
        past_rows = [r for r in rows if r['月份'] < month]
        held = valid_pairs([r for r in rows if r['月份'] == month], field)
        train = valid_pairs(past_rows, field)
        if not held or len(train) < 4:
            continue
        earlier = score_methods(past_rows, field)
        # At this historical origin, only earlier finished fee months can select the model.
        method = min(earlier, key=lambda s:s['回测MAE'])['方法'] if earlier and earlier[0]['回测月数'] >= 3 else '历史加权费用率'
        forecast_sales = test['实际整月销售']-test['实际余期销售']+test['周月结合余期销售']
        pred = parameters(train, method, forecast_sales)
        if pred:
            joint.append({'截止日期':test['截止日期'], '训练截止月份':train[-1]['月份'],
                          '方法':method, '预计销售额':forecast_sales, '预计费用':pred['预测值'],
                          '实际费用':held[0]['费用'], '绝对误差':abs(pred['预测值']-held[0]['费用'])})
    den = total(abs(t['实际费用']) for t in joint)
    out.update({**{k:v for k,v in best.items() if k != '回测明细'}, **fit,
                '预测费用率':fit['预测值']/sales, '固定基线占比':fit['固定基线']/fit['预测值'] if fit['预测值'] else None,
                '参考下沿':max(0,min(lower,upper)-best['回测MAE']),
                '参考上沿':max(lower,upper)+best['回测MAE'],
                '低销售情景费用':lower, '高销售情景费用':upper, '候选方法':candidates,
                '回测明细':best['回测明细'], '联合回测明细':joint,
                '联合回测WAPE':total(t['绝对误差'] for t in joint)/den if den else None,
                '联合回测月数':len(joint),
                '状态':'按历史月度销售规模估费；误差带同时纳入销售范围与条件费用MAE；非置信区间'})
    return out


def summarize_months(rows, fields, label):
    valid = [r for r in rows if all(r['财务'][f] is not None and r['未填'][f] == 0 for f in fields)]
    expense = total(r['财务'][f] for r in valid for f in fields) if valid else None
    sales = total(r['订单销售'] for r in valid) if valid and all(r['订单销售'] is not None for r in valid) else None
    finance_complete = valid and all(r['财务']['最终收入'] is not None and not r['未填']['最终收入'] for r in valid)
    revenue = total(r['财务']['最终收入'] for r in valid) if finance_complete else None
    return {'对照':label, '费用金额':expense, '订单销售额':sales, '财务收入':revenue,
            '订单费用率':expense/sales if expense is not None and sales and sales > 0 else None,
            '财务费用率':expense/revenue if expense is not None and revenue and revenue > 0 else None,
            '月份':'、'.join(r['月份'] for r in valid), '完整月份数':len(valid), '请求月份数':len(rows)}


def analyze(scope, sales, low, high, horizon=1, rolling=None):
    rows = load_history(scope)
    tests = (rolling or {}).get('周月衔接',{}).get('周月回测明细',[])
    costs = [category_fit(rows, cat, label, field, sales, low, high, horizon, tests) for cat,label,field in CATEGORIES]
    fields = [c[2] for c in CATEGORIES]
    monthly = []
    for r in rows:
        record = summarize_months([r], fields, r['月份'])
        record.update({'月份':r['月份'], '订单销售额':r['订单销售'],
                       '财务收入':r['财务']['最终收入'] if not r['未填']['最终收入'] else None,
                       '已填费用合计':total(r['财务'][f] for f in fields) if any(r['财务'][f] is not None for f in fields) else None,
                       '财务毛利率':r['财务']['最终毛利']/r['财务']['最终收入']
                       if r['财务']['最终收入'] and r['财务']['最终收入'] > 0 and r['财务']['最终毛利'] is not None
                       and not r['未填']['最终收入'] and not r['未填']['最终毛利'] else None,
                       '费用未填单元格数':sum(r['未填'][f] for f in fields)})
        for cat,label,field in CATEGORIES:
            record[label] = r['财务'][field] if not r['未填'][field] else None
            record[cat+'费用率'] = r['财务'][field]/r['订单销售'] if r['订单销售'] and r['订单销售'] > 0 and r['财务'][field] is not None and not r['未填'][field] else None
        monthly.append(record)
    benchmarks = []
    for cat,label,field in [('全部费用','全部费用',None), *CATEGORIES]:
        fs = fields if field is None else [field]
        complete = [r for r in rows if all(r['财务'][f] is not None and not r['未填'][f] for f in fs)]
        peer = sorted([r for r in complete if r['订单销售'] and r['订单销售'] > 0], key=lambda r:abs(math.log(r['订单销售']/sales)))[:3] if sales and sales > 0 else []
        for label2, subset in [('最近完整月',complete[-1:]),('近3完整月',complete[-3:]),('历史完整月',complete),('相近销售规模3月',peer)]:
            benchmarks.append({'费用大类':cat,**summarize_months(subset,fs,label2)})
    scenarios = []
    complete = all(c['预测值'] is not None for c in costs)
    if complete:
        for label,x,field in [('较低销售',low,'低销售情景费用'),('基准销售',sales,'预测值'),('较高销售',high,'高销售情景费用')]:
            if x and x > 0:
                e = total(c[field] for c in costs)
                scenarios.append({'情景':label,'预计销售额':x,'预计费用':e,'预计费用率':e/x,
                                  **{c['费用类别']:c[field] for c in costs}})
    gross = [r for r in rows[-3:] if r['财务']['最终收入'] and r['财务']['最终收入'] > 0
             and r['财务']['最终毛利'] is not None and not r['未填']['最终收入'] and not r['未填']['最终毛利']]
    gm = total(r['财务']['最终毛利'] for r in gross)/total(r['财务']['最终收入'] for r in gross) if gross else None
    return {'费用类别预测':costs,'历史费用率对照':benchmarks,'历史月度费用率':monthly,'销售费用情景':scenarios,
            '费用候选方法':[r for c in costs for r in c['候选方法']],
            '参考财务毛利率':gm,'参考财务毛利月份':'、'.join(r['月份'] for r in gross),
            '费用预测说明':'费用与已选周月销售预测联动；逐类比较8种金额、加权费率、相近销售规模及非负固定＋随销混合模型。按时间滚动留出至少3个月，给定该月已实现销售额比较费用条件MAE后选型；这不是销量未知时的联合预测精度。联合回测另外在历史同进度用当时销售预测与当时可选费用模型检验，未使用未来费用选模。历史费率均为费用合计÷同月销售合计，不平均月费率；财务与订单分母分别列示。费用未填的月份不作完整月训练；已填负调整保留，预测支出非负。固定基线是统计截距或金额模型，不能据此认定合同固定支出。参考范围叠加销售敏感度与费用条件MAE，四类带相加，非置信区间。仅2026年1—9月，无法计算同比；活动计划、结算规则及本月实际费用仍缺。未对费用率施加毛利率上限。'}


def add_snapshot(snapshot, refresh_rows=False):
    """Keep dynamic-query provenance in sync on ordinary future refreshes."""
    import marketing_effect
    query = snapshot['queries'].get('report_expense_sales_linkage')
    if not query:
        return
    if refresh_rows:
        scopes = sorted({r['范围'] for r in query['rows']})
        query['rows'] = [{**r,'范围':scope} for scope in scopes for r in marketing_effect.analyze(scope)['月度']]
    definitions = query['source'].setdefault('metricDefinitions', [])
    definitions[:] = [d for d in definitions if d['label'] not in ('费用稳定性与可选月份预算','销售联动费用预算')]
    definitions.append({'label':'销售联动费用预算',
        'definition':'expense_budget.py与expense_diagnostics.py：动态/api/expense-diagnostics按合并客户拟合4大费用类别，不与41细项重复。在确定周月联动销售预测后，以同月订单发货销额为驱动；原金额模型保留对照。8方法包括上月/近3月/历史金额、上月/近3月/历史加权费率、对数销售距离最近3月费率和非负固定＋随销混合。至少4个训练月、至少3个测试月，给定实际销售检验条件费用MAE并选型；联合回测另用当时销售预测和当时仅此前费用的选择。缺失费用月不作完整月训练，负调整保留；费率按合计相除。财务与订单历史分母分列，不强制对齐。销售敏感度情景叠加条件MAE给参考范围，非置信区间。仅2026年无法同比；不按毛利率封顶，不推断合同固定费。联名无费用利润，全部范围分母扣除联名销售预测；若联名预测不可用则预算分母留空。',
        'componentIds':['expense-category-overview','expense-patterns','expense-fixed-candidates','expense-next-month-budget',
                        'expense-budget-benchmarks','expense-sales-sensitivity','expense-budget-monthly-rates','expense-budget-candidates']})
