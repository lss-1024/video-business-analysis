"""用户最新版旺店通订单：只读流式提取，保留源行，不按订单金额替代总销额。"""
import csv,json,hashlib
from collections import Counter,defaultdict
from datetime import date,datetime,timedelta
from decimal import Decimal,InvalidOperation
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from inspect_latest_orders import SOURCE,NS,structure,strings,cells
HERE=Path(__file__).resolve().parent
OUT=HERE.parent/'订单底数据_联名单列_20261022_最新版3'
UPDATE_DAY=date(2026,10,22)
TOKENS=('大客户','大单品','线下闭环')
SELECT={'B':'订单编号','I':'订单状态','L':'订单退款状态','M':'订单明细退款状态','N':'交易时间','P':'发货时间','Q':'客户唯一编码','R':'客户网名','AZ':'货品编号','BA':'货品名称','BC':'规格名称','BD':'分类','BG':'数量','BN':'总销额','BO':'单位','CF':'客户编号','DL':'所属区域','DN':'合并客户名字','DT':'渠道类型','EE':'客户经营属性','EL':'财务标价','EP':'财务成本总金额','FA':'26年7月对应业务单元'}
SELECT.update({'EY':'26年7月对应大区','FH':'渠道产品类型'})
SELECT.update({'ED':'合并产品名字'})
def number(v):
    if v is None or not str(v).strip():return None
    try:
        d=Decimal(str(v).replace(',',''));return d if d.is_finite() else None
    except InvalidOperation:return None
def parse_date(v,epoch):
    if not v:return ''
    try:
        d=number(v)
        dt=(epoch+timedelta(days=int(d))).date() if d is not None else date.fromisoformat(str(v)[:10].replace('/','-'))
        return dt.isoformat() if 2000<=dt.year<=2100 else ''
    except (ValueError,OverflowError):return ''
def rows():
    with ZipFile(SOURCE) as z:
        ss=strings(z);sheet=structure(z)[0]
        wb=ET.fromstring(z.read('xl/workbook.xml'));prop=wb.find('m:workbookPr',NS)
        epoch=datetime(1904,1,1) if prop is not None and prop.get('date1904') in ('1','true') else datetime(1899,12,30)
        with z.open(sheet['path']) as f:
            for _,row in ET.iterparse(f,events=['end']):
                if row.tag!=f"{{{NS['m']}}}row":continue
                rowno=int(row.get('r'));cs=cells([c for c in row if ''.join(x for x in c.get('r','') if x.isalpha()) in SELECT],ss)
                if rowno==1:
                    for col,name in SELECT.items():
                        assert cs[col]['value']==name,(col,name,cs.get(col))
                    row.clear();continue
                r={name:str(cs.get(col,{}).get('value') or '').strip() for col,name in SELECT.items()}
                if any(cs.get(col,{}).get('formula') or cs.get(col,{}).get('type')=='e' for col in SELECT):raise ValueError(f'第{rowno}行所选字段存在公式或错误值，停止更新')
                trade=parse_date(r['交易时间'],epoch);ship=parse_date(r['发货时间'],epoch)
                r.update({'来源行号':rowno,'来源工作表':sheet['name'],'交易日期':trade,'发货日期':ship,'分析日期':ship or trade,'日期依据':'发货时间' if ship else '交易时间回退（发货时间缺失）'})
                row.clear();yield r
def reason(r):
    if not any(t in r['26年7月对应业务单元'] for t in TOKENS):return '业务单元不包含大客户、大单品或线下闭环'
    if '2026-01'<=r.get('交易日期','')[:7]<='2026-06' and r.get('26年7月对应大区')=='线上分销':return '1—6月线上分销（交易日期）'
    value=number(r['总销额']);dt=r['分析日期'];state=r['订单状态']
    if value is None:return '总销额缺失或无效'
    if not dt:return '无有效发货或交易日期'
    if not dt.startswith('2026-'):return '非2026年'
    if dt>UPDATE_DAY.isoformat():return '日期晚于本次更新日'
    if value==0 and state=='退货订单':return ''
    if value>=0 and state and state not in ('已完成','已发货'):return '非负记录未完成或未发货'
    if value>=0 and (r['订单退款状态'] or r['订单明细退款状态']):return '非负记录带退款状态，金额待核实'
    return ''
def prepare():
    OUT.mkdir(exist_ok=True);before=hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    counts=Counter();units=Counter();kept=[];excluded=[];all_count=0;sku_units=defaultdict(set)
    for r in rows():
        if r['货品编号'] and r['单位']:sku_units[r['货品编号']].add(r['单位'])
        all_count+=1;units[r['26年7月对应业务单元']]+=1;why=reason(r)
        if why:counts[why]+=1;excluded.append({'来源行号':r['来源行号'],'业务单元':r['26年7月对应业务单元'],'排除原因':why})
        else:kept.append(r)
        if all_count%20000==0:print(json.dumps({'已扫描行数':all_count,'已纳入行数':len(kept)},ensure_ascii=False),flush=True)
    after=hashlib.sha256(SOURCE.read_bytes()).hexdigest();assert before==after
    assert all_count==len(kept)+sum(counts.values())
    aliases=defaultdict(set)
    for r in kept:
        if r['客户网名'] and r['合并客户名字']:aliases[r['客户网名']].add(r['合并客户名字'])
    groups=defaultdict(list)
    for r in kept:
        original=r['合并客户名字'];nick=r['客户网名'];matches=aliases.get(nick,set())
        # 最新文件内同名网名唯一映射；不覆盖原表，不凭近似相似度合并客户。
        r['合并客户名称']=original or (next(iter(matches)) if len(matches)==1 else '合并客户未提供')
        r['合并名称来源']='原表' if original else '客户网名唯一匹配' if len(matches)==1 else '待核对'
        ip=r.get('渠道产品类型')=='IP联名产品'
        r['原数量单位']=r['单位'];r['数量单位依据']='原表' if r['单位'] else '缺失'
        if ip and not r['单位'] and len(sku_units[r['货品编号']])==1:
            r['单位']=next(iter(sku_units[r['货品编号']]))
            r['数量单位依据']='同一原文件商品编码唯一单位映射；原单元格为空'
        r['利润处理']='不计算利润' if ip else '计算利润'
        if ip:
            r['合并客户名称']='联名客户';r['合并名称来源']='渠道产品类型=IP联名产品；用户指定单列'
        cid=r['客户编号'] or r['客户唯一编码'];r['分析客户编号']=cid
        r['客户编号来源']='客户编号' if r['客户编号'] else '客户唯一编码' if r['客户唯一编码'] else '未提供'
        oid=r['订单编号'] or '缺订单号:'+str(r['来源行号'])
        sign='退单' if number(r['总销额'])<0 else '正向或零额'
        groups[(oid,r['分析日期'],cid,r['合并客户名称'],r['26年7月对应业务单元'],sign,r['订单状态'])].append(r)
    output=[]
    for key,rs in groups.items():
        oid,dt,cid,name,bu,sign,state=key;tid=oid+'#'+hashlib.sha256('|'.join(key[1:]).encode()).hexdigest()[:12]
        identity={f:' / '.join(sorted({r[f] for r in rs if r[f]})) for f in ['客户网名','客户编号来源','合并名称来源']}
        identity.update({f:rs[0][f] if len({r[f] for r in rs})==1 else '' for f in ['交易日期','发货日期','日期依据']})
        base={'日期':dt,'渠道':name,'合并客户名称':name,'原合并客户名称':' / '.join(sorted({r['合并客户名字'] for r in rs if r['合并客户名字']})),'原经营渠道':rs[0]['渠道类型'],**identity,'合并名称依据':'原表合并客户名字；空值仅使用本文件客户网名唯一映射','订单编号':tid,'原订单编号':oid,'客户编号':cid,'客户类型':'渠道客户' if any(r['客户经营属性'] in ('经销商','分销商','渠道客户','零售商') for r in rs) else '身份待核实','订单状态':state,'业务单元':bu,'地区':rs[0]['所属区域'],'来源工作表':rs[0]['来源工作表'],'26年7月对应大区':rs[0].get('26年7月对应大区','')}
        ip=name=='联名客户'
        base.update({'渠道产品类型':'IP联名产品' if ip else ' / '.join(sorted({r.get('渠道产品类型','') for r in rs if r.get('渠道产品类型')})),'利润处理':'不计算利润' if ip else '计算利润'})
        revenue=sum(number(r['总销额']) for r in rs)
        costs=[Decimal(0) if number(r['总销额'])==0 and r['订单状态']=='退货订单' else number(r['财务成本总金额']) for r in rs]
        cost=sum(costs) if all(v is not None for v in costs) else None
        base['来源财务成本总金额']=str(cost) if cost is not None else ''
        if ip:cost=None
        output.append({**base,'记录类型':'订单','来源行号':','.join(str(r['来源行号']) for r in rs),'总销额':str(revenue),'财务成本总金额':str(cost) if cost is not None else '', '金额依据':'源商品行总销额合计；源订单号='+oid})
        for r,c in zip(rs,costs):
            output.append({**base,**{f:r[f] for f in ['交易日期','发货日期','日期依据']},'客户网名':r['客户网名'],'原合并客户名称':r['合并客户名字'],'合并名称来源':r['合并名称来源'],'记录类型':'商品','来源行号':str(r['来源行号']),'订单行编号':f'旺店通:{before[:12]}:{r["来源行号"]}','商品编码':r['货品编号'],'商品名称':r['货品名称'],'合并产品名称':r['合并产品名字'],'品类':r['分类'],'规格':r['规格名称'],'数量':r['数量'],'数量单位':r['单位'],'原数量单位':r['原数量单位'],'数量单位依据':r['数量单位依据'],'总销额':r['总销额'],'来源财务成本总金额':str(c) if c is not None else '', '财务成本总金额':str(c) if c is not None and not ip else '', '标价单价':r['财务标价'],'金额依据':'原表BN总销额、EP财务成本总金额；零额退货订单成本归零'})
    meta={'name':SOURCE.name,'kind':'local-latest-wdt-workbook','path':str(SOURCE),'sha256':before,'sourceRows':all_count,'includedSourceRows':len(kept),'excludedSourceRows':dict(counts),'businessUnits':dict(units),'coverage':'本次只读完整扫描最新版旺店通工作簿；仅2026年，26年7月对应业务单元包含大客户、大单品或线下闭环。该字段为归属分类，日期不局限7月。','grain':'源商品行金额聚合为交易；商品明细单列，不重复累计整单金额。保留原工作表与行号。','warning':'未确认终端消费者身份；无客户编号的记录计财务，不计客户购买次数。原始客户编号空值仅用原表客户唯一编码，未用网名伪造编号。','groupingField':'合并客户名字','readAt':datetime.now().astimezone().isoformat(),'dateStart':min(r['分析日期'] for r in kept),'dateEnd':max(r['分析日期'] for r in kept),'salesField':'总销额','costField':'财务成本总金额','originalUnchanged':True}
    meta['coverage']+='先筛业务单元，业务单元空值全部排除；再按交易日期排除1—6月线上分销。IP联名单列联名客户，保留销售，不计利润。'
    meta['collaborationRule']='FH渠道产品类型=IP联名产品单独归联名客户；保留原合并名；计销售额和数量，不计成本毛利，不参与财务对账。原单位缺失时仅用本文件同SKU唯一非空单位推断并标记。业务单元及订单状态规则不变。'
    meta.update({'salesDateBasis':'发货时间优先；缺失回退交易时间并逐行标记','customerDateBasis':'客户购买行为按交易日期；无有效交易日期回退发货日期；晚于观察截止的交易不计购买行为','dateBasisCounts':dict(Counter(r['日期依据'] for r in kept))})
    for filename,data in [('01_订单来源明细.csv',kept),('02_排除记录.csv',excluded)]:
        with (OUT/filename).open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(data[0]) if data else ['无记录']);w.writeheader();w.writerows(data)
    (OUT/'统一计算输入.json').write_text(json.dumps({'records':output,'meta':meta},ensure_ascii=False),encoding='utf-8')
    (OUT/'manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'来源行数':all_count,'纳入商品行':len(kept),'聚合交易':len(groups),'日期':[meta['dateStart'],meta['dateEnd']],'排除':dict(counts),'客户编号来源':dict(Counter(r['客户编号来源'] for r in kept)),'业务单元':dict(Counter(r['26年7月对应业务单元'] for r in kept)),'总销额':str(sum(number(r['总销额']) for r in kept))},ensure_ascii=False),flush=True)
if __name__=='__main__':prepare()
