import engine
def customer_detail(customer,scope):
    orders,items,_,_=engine.validate(engine.load_current()['records'])
    selected=[r for r in orders if r.get('客户编号')==customer and (scope==engine.ALL or r['渠道']==scope)]
    by_order=engine.defaultdict(list)
    selected_ids={r['订单编号'] for r in selected}
    for r in items:
        if r['订单编号'] in selected_ids:by_order[r['订单编号']].append(r)
    result=[]
    for r in sorted(selected,key=lambda r:(r['日期'],r['订单编号']),reverse=True):
        result.append({'客户编号':customer,'客户网名':r.get('客户网名') or '未提供','合并客户名称':r['渠道'],'日期':r['日期'],
            '订单编号':r.get('金额依据','').split('源订单号=')[-1] if '源订单号=' in r.get('金额依据','') else r['订单编号'],
            '交易日期':r.get('交易日期',''),'日期依据':r.get('日期依据',''),'交易主键':r['订单编号'],'订单状态':r.get('订单状态',''),'总销额':r['总销额'],'财务成本':r['财务成本总金额'],
            '毛利':r['总销额']-r['财务成本总金额'] if r.get('利润处理')!='不计算利润' and r['财务成本总金额'] is not None else None,
            '利润处理':r.get('利润处理','计算利润'),
            '商品名称':' / '.join(sorted({x['商品名称'] for x in by_order[r['订单编号']] if x.get('商品名称')}))})
    return {'客户编号':customer,'范围':scope,'交易':result}
